#ifndef _BL_CAN_H
#define _BL_CAN_H


// for I2C
#define		EEPROM_24LC64 	0xA0
#define 	EEPROM_PAGE_SIZE 32
#define 	I2C_BLOCK_SIZE	4096	/*when received this number of bytes from UART, write to EEPROM*/
#define 	I2C_SPEED	400000 	/*10 k�� for 100 kHz, 2 k�� for 400 kHz*/

#define MAX_USER_PROG_SZ  0x8000 //32KB

#endif
