blinky#.hex:
	user application load and execution point is at the beginning of sector #
	
blinky#.bin:
	binary file in correspondance with blinky#.hex
	
blinkyR#1L#2.hex:
	user application loaded at the beginning of sector #2 but executed at sector #1.
	If use flashmagic, the hex will be programmed into sector #2, but the code can only be executed from sector #1, which means user have to copy code from sector #2 and progrom into sector #1.