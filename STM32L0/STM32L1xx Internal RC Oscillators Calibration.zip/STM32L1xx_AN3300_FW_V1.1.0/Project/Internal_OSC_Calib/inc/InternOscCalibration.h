/**
  ******************************************************************************
  * @file    Project\Internal_OSC_Calib\inc\InternOscCalibration.h
  * @author  MCD Application Team
  * @version V1.1.0
  * @date    24-January-2012
  * @brief   Header for InternOscCalibration.h
  ******************************************************************************
  * @attention
  *
  * THE PRESENT FIRMWARE WHICH IS FOR GUIDANCE ONLY AIMS AT PROVIDING CUSTOMERS
  * WITH CODING INFORMATION REGARDING THEIR PRODUCTS IN ORDER FOR THEM TO SAVE
  * TIME. AS A RESULT, STMICROELECTRONICS SHALL NOT BE HELD LIABLE FOR ANY
  * DIRECT, INDIRECT OR CONSEQUENTIAL DAMAGES WITH RESPECT TO ANY CLAIMS ARISING
  * FROM THE CONTENT OF SUCH FIRMWARE AND/OR THE USE MADE BY CUSTOMERS OF THE
  * CODING INFORMATION CONTAINED HEREIN IN CONNECTION WITH THEIR PRODUCTS.
  *
  * FOR MORE INFORMATION PLEASE READ CAREFULLY THE LICENSE AGREEMENT FILE
  * LOCATED IN THE ROOT DIRECTORY OF THIS FIRMWARE PACKAGE.
  *
  * <h2><center>&copy; COPYRIGHT 2012 STMicroelectronics</center></h2>
  ******************************************************************************
  */

/* Define to prevent recursive inclusion -------------------------------------*/
#ifndef __INTERNOSC_CALIBRATION_H
#define __INTERNOSC_CALIBRATION_H

/* Includes ------------------------------------------------------------------*/
/* Exported types ------------------------------------------------------------*/
/* Exported constants --------------------------------------------------------*/
/* Private define ------------------------------------------------------------*/
/* Comment this line if the LSE clock is not used as the reference frequency */
#define USE_REFERENCE_LSE

#ifdef USE_REFERENCE_LSE

  #define TIM10_COUNTER_PRESCALER  0
  /* The signal in input capture is divided by 8 */
  #define TIM10_IC_DIVIDER         TIM_ICPSC_DIV8

  /* The LSE is divided by 8 => LSE/8 = 32768/8 = 4096 */
  #define REFERENCE_FREQUENCY     (uint32_t) 4096 /* The reference frequency value in Hz */

#else

  /* If reference frequency is not the LSE and lower than 250 Hz (The TIM10 min frequency),
     the TIM10 counter prescaler should be used.
     Otherwise (the reference frequency is greater than 250 Hz),
     the TIM10 counter prescaler should be set to 0 */
  /* For example, If reference frequency is 50 Hz, the counter prescaler should be 8. 
     In that case the minimum frequency (if HSI is system clock source) is 16MHz/(8*65535) ~ 31 Hz */

  /* If the reference frequency is lower than 31Hz, the counter prescaler should be
     used regarding the reference frequency in input */

  /* The reference frequency is 50 Hz (the signal in input capture is not divided) */
  #define REFERENCE_FREQUENCY     (uint32_t)50 /* The reference frequency value in Hz */

  #define TIM10_COUNTER_PRESCALER  7 /* TIM10 counter is divided by 7 + 1 = 8 */
  /* The signal in input capture is not divided */
  #define TIM10_IC_DIVIDER         TIM_ICPSC_DIV1

#endif /* USE_REFERENCE_LSE */

#define NUMBER_OF_LOOPS    10

/* Uncomment the line below to output sysclk source (HSI or MSI) on MCO pin: PA8 */
#define OUTPUT_INTERNOSC_ON_MCO

/* Exported macro ------------------------------------------------------------*/
#define ABS_RETURN(x)         (x < 0) ? (-x) : x

/* Exported functions ------------------------------------------------------- */
uint32_t InternOsc_CalibrateMinError(void);
ErrorStatus HSI_CalibrateFixedError(uint32_t MaxAllowedError, uint32_t* Freq);
ErrorStatus MSI_CalibrateFixedError(uint32_t MaxAllowedError, uint32_t* Freq);
void RCC_AdjustCalibrationValue(uint8_t InternOsc, uint32_t TrimmingValue);
void CLK_ConfigForCalibration(void);
void TIM10_ConfigForCalibration(void);
void GPIO_ConfigForCalibration(void);

#endif /* __INTERNOSC_CALIBRATION_H */

/******************* (C) COPYRIGHT 2012 STMicroelectronics *****END OF FILE****/
