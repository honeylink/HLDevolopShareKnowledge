/**
  ******************************************************************************
  * @file    stm32l0xx_ll_system.h
  * @author  MCD Application Team
  * @version $VERSION$
  * @date    $DATE$
  * @brief   Header file of SYSTEM LL module.
  @verbatim
  ==============================================================================
                     ##### How to use this driver #####
  ==============================================================================
    [..]
    The LL SYSTEM driver contains a set of generic APIs that can be
    used by user:
      (+) Some of the FLASH features need to be handled in the SYSTEM file.
      (+) Access to DBGCMU registers
      (+) Access to SYSCFG registers
      (+) Access to VREFBUF registers

  @endverbatim
  ******************************************************************************
  * @attention
  *
  * <h2><center>&copy; COPYRIGHT(c) 2015 STMicroelectronics</center></h2>
  *
  * Redistribution and use in source and binary forms, with or without modification,
  * are permitted provided that the following conditions are met:
  *   1. Redistributions of source code must retain the above copyright notice,
  *      this list of conditions and the following disclaimer.
  *   2. Redistributions in binary form must reproduce the above copyright notice,
  *      this list of conditions and the following disclaimer in the documentation
  *      and/or other materials provided with the distribution.
  *   3. Neither the name of STMicroelectronics nor the names of its contributors
  *      may be used to endorse or promote products derived from this software
  *      without specific prior written permission.
  *
  * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
  * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
  * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
  * DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE
  * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
  * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
  * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
  * CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
  * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
  * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
  *
  ******************************************************************************
  */

/* Define to prevent recursive inclusion -------------------------------------*/
#ifndef __STM32L0xx_LL_SYSTEM_H
#define __STM32L0xx_LL_SYSTEM_H

#ifdef __cplusplus
extern "C" {
#endif

/* Includes ------------------------------------------------------------------*/
#include "stm32l0xx.h"

/** @addtogroup STM32L0xx_LL_Driver
  * @{
  */

#if defined (FLASH) || defined (SYSCFG) || defined (DBGMCU) || defined (VREFBUF)

/** @defgroup SYSTEM_LL SYSTEM
  * @{
  */

/* Private types -------------------------------------------------------------*/
/* Private variables ---------------------------------------------------------*/

/* Private constants ---------------------------------------------------------*/


/* Private macros ------------------------------------------------------------*/

/* Exported types ------------------------------------------------------------*/
/* Exported constants --------------------------------------------------------*/
/** @defgroup SYSTEM_LL_Exported_Constants SYSTEM Exported Constants
  * @{
  */


/** @defgroup SYSTEM_LL_EC_ABP1_GRP1_STOP_IP DBGMCU ABP1 GRP1 STOP IP
  * @{
  */
#define LL_DBGMCU_ABP1_GRP1_TIM2_STOP      DBGMCU_APB1_FZ_DBG_TIM2_STOP   /*!< The counter clock of TIM2 is stopped when the core is halted*/
#define LL_DBGMCU_ABP1_GRP1_TIM6_STOP      DBGMCU_APB1_FZ_DBG_TIM6_STOP   /*!< The counter clock of TIM6 is stopped when the core is halted*/
#define LL_DBGMCU_ABP1_GRP1_RTC_STOP       DBGMCU_APB1_FZ_DBG_RTC_STOP    /*!< The clock of the RTC counter is stopped when the core is halted*/
#define LL_DBGMCU_ABP1_GRP1_WWDG_STOP      DBGMCU_APB1_FZ_DBG_WWDG_STOP    /*!< The window watchdog counter clock is stopped when the core is halted*/
#define LL_DBGMCU_ABP1_GRP1_IWDG_STOP      DBGMCU_APB1_FZ_DBG_IWDG_STOP    /*!< The independent watchdog counter clock is stopped when the core is halted*/
#define LL_DBGMCU_ABP1_GRP1_I2C1_STOP      DBGMCU_APB1_FZ_DBG_I2C1_STOP    /*!< The I2C1 SMBus timeout is frozen*/
#define LL_DBGMCU_ABP1_GRP1_I2C2_STOP      DBGMCU_APB1_FZ_DBG_I2C2_STOP    /*!< The I2C2 SMBus timeout is frozen*/
#define LL_DBGMCU_ABP1_GRP1_LPTIM1_STOP    DBGMCU_APB1_FZ_DBG_LPTIMER_STOP /*!< The counter clock of LPTIM1 is stopped when the core is halted*/
/**
  * @}
  */


/**
  * @}
  */

/* Exported macro ------------------------------------------------------------*/

/* Exported functions --------------------------------------------------------*/

/**
  * @brief  Freeze APB1 peripherals (group1 peripherals)
  * @rmtoll DBGMCU_APB1FZR1 DBG_xxxx_STOP  LL_DBGMCU_ABP1_GRP1_FreezePeriph
  * @param  Periphs This parameter can be a combination of the following values:
  *         @arg @ref LL_DBGMCU_ABP1_GRP1_TIM2_STOP
  *         @arg @ref LL_DBGMCU_ABP1_GRP1_TIM3_STOP
  *         @arg @ref LL_DBGMCU_ABP1_GRP1_TIM4_STOP
  *         @arg @ref LL_DBGMCU_ABP1_GRP1_TIM5_STOP
  *         @arg @ref LL_DBGMCU_ABP1_GRP1_TIM6_STOP
  *         @arg @ref LL_DBGMCU_ABP1_GRP1_TIM7_STOP
  *         @arg @ref LL_DBGMCU_ABP1_GRP1_RTC_STOP
  *         @arg @ref LL_DBGMCU_ABP1_GRP1_WWDG_STOP
  *         @arg @ref LL_DBGMCU_ABP1_GRP1_IWDG_STOP
  *         @arg @ref LL_DBGMCU_ABP1_GRP1_I2C1_STOP
  *         @arg @ref LL_DBGMCU_ABP1_GRP1_I2C2_STOP
  *         @arg @ref LL_DBGMCU_ABP1_GRP1_I2C3_STOP
  *         @arg @ref LL_DBGMCU_ABP1_GRP1_CAN_STOP
  *         @arg @ref LL_DBGMCU_ABP1_GRP1_LPTIM1_STOP
  * @retval None
  */
__STATIC_INLINE void LL_DBGMCU_ABP1_GRP1_FreezePeriph(uint32_t Periphs)
{
  SET_BIT(DBGMCU->APB1FZ, Periphs);
}


/**
  * @}
  */

/**
  * @}
  */

#endif /* defined (FLASH) || defined (SYSCFG) || defined (DBGMCU) || defined (VREFBUF) */

/**
  * @}
  */

#ifdef __cplusplus
}
#endif

#endif /* __STM32L0xx_LL_SYSTEM_H */

/************************ (C) COPYRIGHT STMicroelectronics *****END OF FILE****/
