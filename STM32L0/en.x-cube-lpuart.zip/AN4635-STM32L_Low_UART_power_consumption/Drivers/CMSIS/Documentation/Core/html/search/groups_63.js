var searchData=
[
  ['cache_20functions_20_20_28only_20cortex_2dm7_29',['Cache Functions  (only Cortex-M7)',['../group__cache__functions__m7.html',1,'']]],
  ['core_20register_20access',['Core Register Access',['../group___core___register__gr.html',1,'']]]
];
