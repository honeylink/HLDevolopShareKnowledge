/**
  ******************************************************************************
  * @file    LPUART/LPUART_TwoBoards_ComDMA/Src/main.c
  * @author  MCD Application Team
  * @version V1.1.0
  * @date    12-Oct-2015
  * @brief   This sample code shows how to use STM32L0xx UART HAL API to transmit
  *          and receive a data buffer with a communication process based on
  *          DMA transfer.
  *          The communication is done using 2 Boards.
  ******************************************************************************
  * @attention
  *
  * <h2><center>&copy; COPYRIGHT(c) 2015 STMicroelectronics</center></h2>
  *
  * Redistribution and use in source and binary forms, with or without modification,
  * are permitted provided that the following conditions are met:
  *   1. Redistributions of source code must retain the above copyright notice,
  *      this list of conditions and the following disclaimer.
  *   2. Redistributions in binary form must reproduce the above copyright notice,
  *      this list of conditions and the following disclaimer in the documentation
  *      and/or other materials provided with the distribution.
  *   3. Neither the name of STMicroelectronics nor the names of its contributors
  *      may be used to endorse or promote products derived from this software
  *      without specific prior written permission.
  *
  * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
  * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
  * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
  * DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE
  * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
  * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
  * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
  * CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
  * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
  * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
  *
  ******************************************************************************
  */

/* Includes ------------------------------------------------------------------*/
#include "main.h"

/** @addtogroup STM32L0xx_HAL_Examples
  * @{
  */

/** @addtogroup LPUART_TwoBoards_ComDMA
  * @{
  */

/* Private typedef -----------------------------------------------------------*/
/* Private define ------------------------------------------------------------*/
/* Settings configuring the behaviour of this example. Not all combinations are functional. */
#define HSI		
/* Switch to HSI div 4 clock (useful for higher com speeds). */
#define BOARD2
/* Companion board, not intended for direct AN4635 measurements reproduction, used in pair. */
#define DEBUG_OFF
/* Puts SWD pins to analog input mode. */
#define UI
/* LED2 blinking during communication, button to start communication loop. */
#define BD_SPEED                ((uint32_t)9600)
/* Communication speed setting. */
#define RCC_MSIRANGE_SET        RCC_MSIRANGE_1
/* MSI clock speed setting (ignored if HSI is active). */
#define PWR_CR_VOS_CONF         PWR_REGULATOR_VOLTAGE_SCALE2
/* Power regulator setting (ignored if LPRUN is active). */
#define TXSLEEP
/* The device is in Sleep mode during transmission. */
#define RXSLEEP
/* The device is in Sleep mode during reception. */
#define RCC_HCLK_DIV_SETTING    RCC_HCLK_DIV1
/* AHB bus clock division ratio setting. */

/* Private macro -------------------------------------------------------------*/
/* Private variables ---------------------------------------------------------*/
/* UART handler declaration */
UART_HandleTypeDef UartHandle;
UART_WakeUpTypeDef Selection;
__IO ITStatus UartReady = RESET;

/* Buffer used for transmission */
uint8_t aTxBuffer[] = "Technical death metal is a subgenre of metal focusing on complex rhythms, riffs and song structures.";

/* Buffer used for reception */
uint8_t aRxBuffer[RXBUFFERSIZE];

/* Private function prototypes -----------------------------------------------*/
static void SystemClock_Config(void);
static void SystemPower_Config(void);
static void Error_Handler(void);
#ifndef BOARD2
static uint16_t Buffercmp(uint8_t* pBuffer1, uint8_t* pBuffer2, uint16_t BufferLength);
#endif /* BOARD2 */

/* Private functions ---------------------------------------------------------*/

/**
  * @brief  Main program.
  * @param  None
  * @retval None
  */
void main(void)
{
  /* STM32L0xx HAL library initialization:
       - Configure the Flash prefetch
       - Systick timer is configured by default as source of time base, but user 
         can eventually implement his proper time base source (a general purpose 
         timer for example or other time source), keeping in mind that Time base 
         duration should be kept 1ms since PPP_TIMEOUT_VALUEs are defined and 
         handled in milliseconds basis.
       - Low Level Initialization
     */
  HAL_Init();

  /* Configure the system clock */
  SystemClock_Config();

  /* Configure the system Power */
  SystemPower_Config();

  /*##-1- Configure the LPUART peripheral ######################################*/
  /* LPUART1 configured as follow:
      - Word Length = 8 Bits
      - Stop Bit = One Stop bit
      - Parity = None
      - BaudRate = BD_SPEED (9600 baud)
      - Hardware flow control disabled (RTS and CTS signals) */
  UartHandle.Instance        = UARTx;
  UartHandle.Init.BaudRate   = BD_SPEED;
  UartHandle.Init.WordLength = UART_WORDLENGTH_8B;
  UartHandle.Init.StopBits   = UART_STOPBITS_1;
  UartHandle.Init.Parity     = UART_PARITY_NONE;
  UartHandle.Init.HwFlowCtl  = UART_HWCONTROL_NONE;
  UartHandle.Init.Mode       = UART_MODE_TX_RX;

  if (HAL_UART_Init(&UartHandle) != HAL_OK)
  {
    Error_Handler();
  }
  
#ifdef UI
  /* Configure LED2 */
  BSP_LED_Init(LED2);
  /* Configure Button Key */
  BSP_PB_Init(BUTTON_KEY, BUTTON_MODE_GPIO);

  /* Toggle led2 waiting for user to press button */
  BSP_LED_Toggle(LED2);

#ifndef BOARD2
  /* Wait for Button Key press before starting the Communication */
  while (BSP_PB_GetState(BUTTON_KEY) == RESET)
  {}
  /* Wait for Button Key to be release before starting the Communication */
  while (BSP_PB_GetState(BUTTON_KEY) == SET)
  {}
#endif /* BOARD2 */
#endif /* UI */

  /* Infinite loop */
  while (1)
  {

#ifdef UI
    /* Turn led2 off */
    BSP_LED_Toggle(LED2);
#endif /* UI */

#ifndef BOARD2
    /* Arbitrary pause to divide the measurements */
    HAL_Delay( 50 );

    /* The board sends the message and expects to receive it back */

    /*##-2- Start the transmission process #####################################*/
    /* While the UART in reception process, user can transmit data through
      "aTxBuffer" buffer*/
    if (HAL_UART_Transmit_DMA(&UartHandle, (uint8_t*)aTxBuffer, TXBUFFERSIZE) != HAL_OK)
    {
      Error_Handler();
    }

    /* Disable the half transfer interrupt */
    __HAL_DMA_DISABLE_IT(UartHandle.hdmatx, DMA_IT_HT);
    
#ifdef TXSLEEP    
    /* By suspending Tick the Sleep mode is prevented from being wake */
    HAL_SuspendTick();
    HAL_PWR_EnterSLEEPMode(PWR_LOWPOWERREGULATOR_ON, PWR_SLEEPENTRY_WFI);
    HAL_ResumeTick();
#endif /* TXSLEEP */
    
    /*##-3- Wait for the end of the transfer ###################################*/
    while (UartReady != SET)
    {
      __WFE();
    }

    /* Reset transmission flag */
    UartReady = RESET;
#endif /* BOARD2 */

    /*##-4- Put UART peripheral in reception process ###########################*/
    if (HAL_UART_Receive_DMA(&UartHandle, (uint8_t *)aRxBuffer, RXBUFFERSIZE) != HAL_OK)
    {
      Error_Handler();
    }

    /* Disable the half transfer interrupt */
    __HAL_DMA_DISABLE_IT(UartHandle.hdmarx, DMA_IT_HT);

#ifndef BOARD2
#ifdef RXSLEEP
    /* By suspending Tick the Sleep mode is prevented from being wake */
    HAL_SuspendTick();
    HAL_PWR_EnterSLEEPMode(PWR_LOWPOWERREGULATOR_ON, PWR_SLEEPENTRY_WFI);
    HAL_ResumeTick();
#endif /* RXSLEEP */
#endif /* BOARD2 */

    /*##-6- Wait for the end of the transfer ###################################*/
    while (UartReady != SET)
    {
      __WFE();
    }
    /* Reset transmission flag */
    UartReady = RESET;

#ifdef BOARD2
    /* Wait 10 ms before returning the message */
    HAL_Delay( 10 );

    if (HAL_UART_Transmit_DMA(&UartHandle, (uint8_t *)aRxBuffer, RXBUFFERSIZE) != HAL_OK)
    {
#ifndef DEBUG_OFF
      Error_Handler();
      BSP_LED_On(LED2);
#endif /* DEBUG_OFF */
    }

    while (UartReady != SET)
    {
      __WFE();
    }

    /* Reset transmission flag */
    UartReady = RESET;

#else /* BOARD2 */
    /*##-7- Compare the sent and received buffers ############################## */
    if (Buffercmp((uint8_t*)aTxBuffer, (uint8_t*)aRxBuffer, RXBUFFERSIZE))
    {
#ifndef DEBUG_OFF
      Error_Handler();
#ifdef UI
    /* Turn led2 on */
      BSP_LED_On(LED2);
#endif /* UI */
#endif /* DEBUG_OFF */
    }
#endif /* BOARD2 */
  }
}

/**
  * @brief  System Clock Configuration
  *         The system Clock is configured as follow :
  *            System Clock source            = (MSI/HSI)
  * @param  None
  * @retval None
  */
static void SystemClock_Config(void)
{
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_PeriphCLKInitTypeDef PeriphClkInit = {0};

  /* Enable Power Control clock */
  __HAL_RCC_PWR_CLK_ENABLE();

#ifdef HSI
  /* Enable HSI Oscillator and activate PLL with HSI as source */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSI;
  RCC_OscInitStruct.HSIState = RCC_HSI_DIV4;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_OFF;
  /**/
#else /* HSI */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_MSI | RCC_OSCILLATORTYPE_LSE;
  RCC_OscInitStruct.MSIState = RCC_MSI_ON;
  RCC_OscInitStruct.LSEState = RCC_LSE_ON;
  RCC_OscInitStruct.MSIClockRange = RCC_MSIRANGE_SET;
#endif /* HSI */
  HAL_RCC_OscConfig(&RCC_OscInitStruct);

  /* Select PLL as system clock source and configure the HCLK, PCLK1 and PCLK2
     clocks dividers */
  RCC_ClkInitStruct.ClockType = (RCC_CLOCKTYPE_SYSCLK | RCC_CLOCKTYPE_HCLK | RCC_CLOCKTYPE_PCLK1 | RCC_CLOCKTYPE_PCLK2);
#ifdef HSI
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_HSI;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV_SETTING;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV_SETTING;
  HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_0);
  
  /* Now the MSI can be turned off */
  CLEAR_BIT(RCC->CR, RCC_CR_MSION);
  
  /* HSI is configured to provide clock to the LPUART */
  PeriphClkInit.PeriphClockSelection = RCC_PERIPHCLK_LPUART1;
  PeriphClkInit.Lpuart1ClockSelection = RCC_LPUART1CLKSOURCE_HSI;
  HAL_RCCEx_PeriphCLKConfig(&PeriphClkInit);  
#else /* HSI */
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_MSI;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV_SETTING;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV_SETTING;
  HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_0);
  
  /* LSE is configured to provide clock to the LPUART */
  PeriphClkInit.PeriphClockSelection = RCC_PERIPHCLK_LPUART1;
  PeriphClkInit.Lpuart1ClockSelection = RCC_LPUART1CLKSOURCE_LSE;
  HAL_RCCEx_PeriphCLKConfig(&PeriphClkInit);  
#endif /* HSI */  
}

/**
  * @brief  System Power Configuration
  *         The system Power is configured.
  * @param  None
  * @retval None
  */
static void SystemPower_Config(void)
{
  GPIO_InitTypeDef GPIO_InitStructure;

  __HAL_PWR_VOLTAGESCALING_CONFIG(PWR_CR_VOS_CONF);

  /* Enable Ultra low power mode*/
  HAL_PWREx_EnableUltraLowPower();

  /* Enable the fast wake up from Ultra low power mode*/
  HAL_PWREx_EnableFastWakeUp();

  /* Enable GPIOs clock */
  __HAL_RCC_GPIOA_CLK_ENABLE();
  __HAL_RCC_GPIOB_CLK_ENABLE();
  __HAL_RCC_GPIOC_CLK_ENABLE();
  __HAL_RCC_GPIOD_CLK_ENABLE();
  __HAL_RCC_GPIOH_CLK_ENABLE();

  /* Configure all GPIO port pins in Analog Input mode (floating input trigger OFF) */
  GPIO_InitStructure.Pin = GPIO_PIN_All;
  GPIO_InitStructure.Mode = GPIO_MODE_ANALOG;
  GPIO_InitStructure.Pull = GPIO_NOPULL;
#ifdef DEBUG_OFF
  HAL_GPIO_Init(GPIOA, &GPIO_InitStructure);
#endif /* DEBUG_OFF */
  HAL_GPIO_Init(GPIOC, &GPIO_InitStructure);
  HAL_GPIO_Init(GPIOD, &GPIO_InitStructure);
  HAL_GPIO_Init(GPIOH, &GPIO_InitStructure);
  GPIO_InitStructure.Pin = ~(UARTx_TX_PIN | UARTx_RX_PIN);
  HAL_GPIO_Init(GPIOB, &GPIO_InitStructure);

  /* Disable GPIOs clock */
  __HAL_RCC_GPIOA_CLK_DISABLE();  
  __HAL_RCC_GPIOB_CLK_DISABLE();
  __HAL_RCC_GPIOC_CLK_DISABLE();
  __HAL_RCC_GPIOD_CLK_DISABLE();
  __HAL_RCC_GPIOH_CLK_DISABLE();  
}

/**
  * @brief  Tx Transfer completed callback
  * @param  huart: UART handle.
  * @note   This example shows a simple way to report end of DMA Tx transfer, and
  *         you can add your own implementation.
  * @retval None
  */
void HAL_UART_TxCpltCallback(UART_HandleTypeDef *huart)
{
  /* Set transmission flag: transfer complete*/
  UartReady = SET;
}

/**
  * @brief  Rx Transfer completed callback
  * @param  huart: UART handle
  * @note   This example shows a simple way to report end of DMA Rx transfer, and
  *         you can add your own implementation.
  * @retval None
  */
void HAL_UART_RxCpltCallback(UART_HandleTypeDef *huart)
{
  /* Set transmission flag: transfer complete*/
  UartReady = SET;
}

/**
  * @brief  UART error callbacks
  * @param  huart: UART handle
  * @note   This example shows a simple way to report transfer error, and you can
  *         add your own implementation.
  * @retval None
  */
void HAL_UART_ErrorCallback(UART_HandleTypeDef *huart)
{
  while (1)
  {}
}

#ifndef BOARD2
/**
  * @brief  Compares two buffers.
  * @param  pBuffer1, pBuffer2: buffers to be compared.
  * @param  BufferLength: buffer's length
  * @retval 0  : pBuffer1 identical to pBuffer2
  *         >0 : pBuffer1 differs from pBuffer2
  */
static uint16_t Buffercmp(uint8_t* pBuffer1, uint8_t* pBuffer2, uint16_t BufferLength)
{
  uint16_t retval = 0;

  while ((BufferLength--) && (retval == 0))
  {
    if (pBuffer1[BufferLength] != pBuffer2[BufferLength])
    {
      retval = BufferLength + 1;
    }
  }

  return retval;
}
#endif /* BOARD2 */

/**
  * @brief  This function is executed in case of error occurrence.
  * @param  None
  * @retval None
  */
static void Error_Handler(void)
{
  while (1)
  {}
}

#ifdef  USE_FULL_ASSERT

/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t* file, uint32_t line)
{
  /* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */

  /* Infinite loop */
  while (1)
  {}
}
#endif /* USE_FULL_ASSERT */

/**
  * @}
  */

/**
  * @}
  */

/************************ (C) COPYRIGHT STMicroelectronics *****END OF FILE****/
