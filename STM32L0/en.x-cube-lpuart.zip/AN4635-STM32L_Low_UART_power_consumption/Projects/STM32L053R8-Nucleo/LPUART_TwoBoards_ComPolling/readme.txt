/**
  @page LPUART_TwoBoards_ComPolling LPUART Two Boards Communication Polling example

  @verbatim
  ******************** (C) COPYRIGHT 2015 STMicroelectronics *******************
  * @file    LPUART/LPUART_TwoBoards_ComPolling/readme.txt 
  * @author  MCD Application Team
  * @version V1.1.0
  * @date    12-Oct-2015
  * @brief   Description of the LPUART Two Boards Communication Polling example.
  ******************************************************************************
  *
  * Redistribution and use in source and binary forms, with or without modification,
  * are permitted provided that the following conditions are met:
  *   1. Redistributions of source code must retain the above copyright notice,
  *      this list of conditions and the following disclaimer.
  *   2. Redistributions in binary form must reproduce the above copyright notice,
  *      this list of conditions and the following disclaimer in the documentation
  *      and/or other materials provided with the distribution.
  *   3. Neither the name of STMicroelectronics nor the names of its contributors
  *      may be used to endorse or promote products derived from this software
  *      without specific prior written permission.
  *
  * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
  * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
  * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
  * DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE
  * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
  * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
  * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
  * CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
  * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
  * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
  *
  ******************************************************************************
  @endverbatim

@par Firmware Description 

This firmware purpose is to provide easier means to replicate the measurements
in AN4635.

Board: STM32L053R8-Nucleo (embeds a STM32L053R8T6 device)
Tx Pin: PB.10
Rx Pin: PB.11
   _________________________                       _________________________ 
  |           ______________|                     |______________           |
  |          |LPUART        |                     |        LPUART|          |
  |          |              |                     |              |          |
  |          |           TX |_____________________| RX           |          |
  |          |              |                     |              |          |
  |          |              |                     |              |          |
  |          |              |                     |              |          |
  |          |           RX |_____________________| TX           |          |
  |          |              |                     |              |          |
  |          |______________|                     |______________|          |
  |                         |                     |                         |
  |                      GND|_____________________|GND                      |
  |_STM32_Board 1___________|                     |_STM32_Board 2___________|

Two boards are connected as shown on the picture above.
Board 1: transmitting then receiving board
Board 2: receiving then transmitting board
The user presses the User push-button on board 1, if the UI compilation switch is enabled.
Then, board 1 starts the loop and sends in polling mode a message to board 2 that sends
it back to board 1.
Finally, board 1 compare the received message to that sent.
If the messages are the same, the test passes and loop restarts.

WARNING: as both boards do not behave the same way, "BOARD2" compilation
switch is defined in /Src/main.c and must be disabled at compilation time
before loading the executable in the board that first transmits then receives.
The receiving then transmitting board needs to be loaded with an executable
software obtained with "BOARD2" enabled, obtainable from DMA variant of the code. 

STM32L053R8-Nucleo board LED is used to monitor the transfer status:
- While board 1 is waiting for the user to press the User push-button, its LED2 is on.
- As the communication loop test passes, LED2 is blinking. Stops at failure.

At the beginning of the main program the HAL_Init() function is called to reset 
all the peripherals, initialize the Flash interface and the systick.
Then the SystemClock_Config() function is used to configure the system
clock (SYSCLK) to run selected speed.

The LPUART is configured as follow:
    - BaudRate = 9600 baud  (BD_SPEED define)
    - Word Length = 8 bits (8 data bits, no parity bit)
    - One Stop Bit
    - No parity
    - Hardware flow control disabled (RTS and CTS signals)
      
@note The application need to ensure that the SysTick time base is always set to 1 millisecond
      to have correct HAL operation.

@note USARTx/UARTx instance used and associated resources can be updated in "main.h"
file depending hardware configuration used. Useful to compare with regular USART operation.

@par Directory contents 
  - LPUART_TwoBoards_ComPolling/Inc/stm32l0xx_hal_conf.h    HAL configuration file
  - LPUART_TwoBoards_ComPolling/Inc/stm32l0xx_it.h          interrupt handlers header file
  - LPUART_TwoBoards_ComPolling/Inc/main.h                  Header for main.c module  
  - LPUART_TwoBoards_ComPolling/Src/stm32l0xx_it.c          interrupt handlers
  - LPUART_TwoBoards_ComPolling/Src/main.c                  Main program
  - LPUART_TwoBoards_ComPolling/Src/stm32l0xx_hal_msp.c     HAL MSP module
  - LPUART_TwoBoards_ComPolling/Src/system_stm32l0xx.c      STM32L0xx system source file

@par Hardware and Software environment 

  - This example runs on STM32L051xx, STM32L052xx, STM32L053xx STM32L062xx and 
    STM32L063xx device lines RevZ
    
  - This example has been tested with STM32L053R8-Nucleo RevC and can be
    easily tailored to any other supported device and development board.

  - STM32L053R8-Nucleo RevC Set-up
    - Connect a wire between 1st board PB10 (pin 25 in CN10 connector) pin (Uart Tx) 
      to 2nd board PB11 (pin 18 in CN10 connector) pin (Uart Rx)
    - Connect a wire between 1st board PB11 (pin 18 in CN10 connector) pin (Uart Rx)
      to 2nd board PB10 (pin 25 in CN10 connector) pin (Uart Tx)

@par How to use it ? 

In order to make the program work, you must do the following :
 - Open your preferred toolchain 
 - Set the #define preprocessor switches to desired configuration
 - Rebuild all files and load your image into target memory
 - Run the example

 * <h3><center>&copy; COPYRIGHT STMicroelectronics</center></h3>
 */