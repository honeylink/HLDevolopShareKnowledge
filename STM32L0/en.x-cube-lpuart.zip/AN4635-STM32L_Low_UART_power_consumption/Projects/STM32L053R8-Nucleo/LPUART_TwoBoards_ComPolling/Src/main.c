/**
  ******************************************************************************
  * @file    LPUART/LPUART_TwoBoards_ComPolling/Src/main.c
  * @author  MCD Application Team
  * @version V1.1.0
  * @date    12-Oct-2015
  * @brief   This sample code shows how to use STM32L0xx UART HAL API to transmit
  *          and receive a data buffer with a communication process based on
  *          polling transfer.
  *          The communication is done using 2 Boards.
  ******************************************************************************
  * @attention
  *
  * <h2><center>&copy; COPYRIGHT(c) 2015 STMicroelectronics</center></h2>
  *
  * Redistribution and use in source and binary forms, with or without modification,
  * are permitted provided that the following conditions are met:
  *   1. Redistributions of source code must retain the above copyright notice,
  *      this list of conditions and the following disclaimer.
  *   2. Redistributions in binary form must reproduce the above copyright notice,
  *      this list of conditions and the following disclaimer in the documentation
  *      and/or other materials provided with the distribution.
  *   3. Neither the name of STMicroelectronics nor the names of its contributors
  *      may be used to endorse or promote products derived from this software
  *      without specific prior written permission.
  *
  * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
  * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
  * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
  * DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE
  * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
  * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
  * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
  * CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
  * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
  * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
  *
  ******************************************************************************
  */

/* Includes ------------------------------------------------------------------*/
#include "main.h"

/** @addtogroup STM32L0xx_HAL_Examples
  * @{
  */

/** @addtogroup LPUART_TwoBoards_ComPolling
  * @{
  */

/* Private typedef -----------------------------------------------------------*/
/* Private define ------------------------------------------------------------*/
/* Settings configuring the behaviour of this example. Not all combinations are functional */
/*#define HSI*/
/* Activate HSI source for system clock ( useful for higher speeds). */
#define DEBUG_OFF
/* Puts SWD pins to analog input mode. */
/*#define UI*/
/* LED2 blinking during communication, button to start communication loop. */
#define STOP2
/* Device Enters Stop2 mode in between communications. */
#define LPRUN
/* Switch to use low power run mode. */
#define BD_SPEED                ((uint32_t)9600)
/* Communication speed setting. */
#define RCC_MSIRANGE_SET        RCC_MSIRANGE_5
/* MSI clock speed setting (ignored if HSI is active). */
#define PWR_CR_VOS_CONF         PWR_REGULATOR_VOLTAGE_SCALE3
/* Power regulator setting (ignored if LPRUN is active). */
#define TXSLEEP
/* The device is in Sleep mode during transmission. */
#define RXSLEEP
/* The device is in Sleep mode during reception. */
#define RCC_HCLK_DIV_SETTING    RCC_HCLK_DIV1
/* AHB bus clock division ratio setting. */

/* Private macro -------------------------------------------------------------*/
/* Private variables ---------------------------------------------------------*/
/* UART handler declaration */
UART_HandleTypeDef UartHandle;
UART_WakeUpTypeDef Selection;

/* Buffer used for transmission */
uint8_t aTxBuffer[] = "Technical death metal is a subgenre of metal focusing on complex rhythms, riffs and song structures.";

/* Buffer used for reception */
uint8_t aRxBuffer[RXBUFFERSIZE];

/* Private function prototypes -----------------------------------------------*/
HAL_StatusTypeDef HAL_UART_TransmitFast(UART_HandleTypeDef *huart, uint8_t *pData, uint16_t Size);
HAL_StatusTypeDef HAL_UART_ReceiveFast(UART_HandleTypeDef *huart, uint8_t *pData, uint16_t Size);
static void SystemClock_Config(void);
static void SystemPower_Config(void);
static void Error_Handler(void);
static uint16_t Buffercmp(uint8_t* pBuffer1, uint8_t* pBuffer2, uint16_t BufferLength);

/* Private functions ---------------------------------------------------------*/

/**
  * @brief  Main program.
  * @param  None
  * @retval None
  */
void main(void)
{
  /* STM32L0xx HAL library initialization:
       - Configure the Flash prefetch
       - Systick timer is configured by default as source of time base, but user 
         can eventually implement his proper time base source (a general purpose 
         timer for example or other time source), keeping in mind that Time base 
         duration should be kept 1ms since PPP_TIMEOUT_VALUEs are defined and 
         handled in milliseconds basis.
       - Low Level Initialization
     */
  HAL_Init();

  /* Configure the system clock */
  SystemClock_Config();

  /* Configure the system Power */
  SystemPower_Config();

#ifdef UI
  /* Configure LED2 */
  BSP_LED_Init(LED2);

  /* Configure Button Key */
  BSP_PB_Init(BUTTON_KEY, BUTTON_MODE_GPIO);

  /* Toggle led2 waiting for user to press button */
  BSP_LED_On(LED2);

  /* Wait for Button Key press before starting the Communication */
  while (BSP_PB_GetState(BUTTON_KEY) == RESET)
  {}

  /* Wait for Button Key to be release before starting the Communication */
  while (BSP_PB_GetState(BUTTON_KEY) == SET)
  {}
   
  /* Dim led2 */
  BSP_LED_Off(LED2);
#endif /* UI */

  /* Infinite loop */
  while (1)
  {
    /*##-1- Configure the UART peripheral ######################################*/
    /* Put the USART peripheral in the Asynchronous mode (UART Mode) */
    /* UART1 configured as follow:
        - Word Length = 8 Bits
        - Stop Bit = One Stop bit
        - Parity = None
        - BaudRate = 9600 baud
        - Hardware flow control disabled (RTS and CTS signals) */
    UartHandle.Instance        = UARTx;
    UartHandle.Init.BaudRate   = BD_SPEED;
    UartHandle.Init.WordLength = UART_WORDLENGTH_8B;
    UartHandle.Init.StopBits   = UART_STOPBITS_1;
    UartHandle.Init.Parity     = UART_PARITY_NONE;
    UartHandle.Init.HwFlowCtl  = UART_HWCONTROL_NONE;
    UartHandle.Init.Mode       = UART_MODE_TX_RX;
    UartHandle.AdvancedInit.AdvFeatureInit = UART_ADVFEATURE_RXOVERRUNDISABLE_INIT;
    UartHandle.AdvancedInit.OverrunDisable = UART_ADVFEATURE_OVERRUN_DISABLE;

    if (HAL_UART_Init(&UartHandle) != HAL_OK)
    {
      Error_Handler();
    }

    /* Configuring the LPUART specific LP feature - the wakeup from STOP */
    Selection.WakeUpEvent = UART_WAKEUP_ON_STARTBIT;
    HAL_UARTEx_EnableClockStopMode(&UartHandle);
    HAL_UARTEx_EnableStopMode( &UartHandle );
    HAL_UARTEx_StopModeWakeUpSourceConfig( &UartHandle, Selection );
    __HAL_UART_ENABLE_IT(&UartHandle, UART_IT_WUF);

#ifdef UI
    /* Toggle led2 */
    BSP_LED_Toggle(LED2);
#endif /* UI */

    /* Arbitrary pause to divide the measurements */
    HAL_Delay( 50 );

#ifdef LPRUN
    /* Enter LP RUN mode*/

    /* Set MSI range to 1 */
    __HAL_RCC_MSI_RANGE_CONFIG(RCC_MSIRANGE_1);
    /* Set VOS range to 2 */
    __HAL_PWR_VOLTAGESCALING_CONFIG(PWR_REGULATOR_VOLTAGE_SCALE1);
    /* Set control bits */
    HAL_PWREx_EnableLowPowerRunMode();

    while (__HAL_PWR_GET_FLAG(PWR_FLAG_REGLP) == RESET)
    {}
#endif /* LPRUN */

    /*##-2- Put UART peripheral in transmission process ###########################*/
    /* The board sends the message and expects to receive it back */
    if (HAL_UART_TransmitFast(&UartHandle, (uint8_t*)aTxBuffer, TXBUFFERSIZE) != HAL_OK)
    {
      Error_Handler();
    }

    /*##-3- Put MCU in low power mode ###########################*/
#ifdef STOP
#ifdef REG_LP
    HAL_PWREx_DisableLowPowerRunMode();
#endif /* REG_LP */
    HAL_PWR_EnterSTOPMode(PWR_LOWPOWERREGULATOR_ON, PWR_STOPENTRY_WFE);
#else /* STOP */
    HAL_SuspendTick();
    HAL_PWR_EnterSLEEPMode(PWR_LOWPOWERREGULATOR_ON, PWR_STOPENTRY_WFE);
    HAL_ResumeTick();
#endif /* STOP */
    __HAL_PWR_VOLTAGESCALING_CONFIG(PWR_CR_VOS_CONF);

    /*##-4- Put UART peripheral in reception process ###########################*/
    if (HAL_UART_ReceiveFast(&UartHandle, (uint8_t *)aRxBuffer, RXBUFFERSIZE) != HAL_OK)
    {
      Error_Handler();
    }

    /*##-5- Compare the sent and received buffers ##############################*/
    if (Buffercmp((uint8_t*)aTxBuffer, (uint8_t*)aRxBuffer, RXBUFFERSIZE))
    {
#ifndef DEBUG_OFF
      Error_Handler();
#ifdef UI
    /* Turn led2 on */
      BSP_LED_On(LED2);
#endif /* UI */
#endif /* DEBUG_OFF */
    }
  }
}

/**
  * @brief  System Clock Configuration
  *         The system Clock is configured as follow :
  *            System Clock source            = (MSI/HSI)
  * @param  None
  * @retval None
  */
static void SystemClock_Config(void)
{
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_PeriphCLKInitTypeDef PeriphClkInit = {0};

  /* Enable Power Control clock */
  __HAL_RCC_PWR_CLK_ENABLE();

#ifdef HSI
  /* Enable HSI Oscillator and activate PLL with HSI as source */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSI;
  RCC_OscInitStruct.HSIState = RCC_HSI_DIV4;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_OFF;
  /**/
#else /* HSI */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_MSI | RCC_OSCILLATORTYPE_LSE;
  RCC_OscInitStruct.MSIState = RCC_MSI_ON;
  RCC_OscInitStruct.LSEState = RCC_LSE_ON;
  RCC_OscInitStruct.MSIClockRange = RCC_MSIRANGE_SET;
#endif /* HSI */
  HAL_RCC_OscConfig(&RCC_OscInitStruct);

  /* Select PLL as system clock source and configure the HCLK, PCLK1 and PCLK2
     clocks dividers */
  RCC_ClkInitStruct.ClockType = (RCC_CLOCKTYPE_SYSCLK | RCC_CLOCKTYPE_HCLK | RCC_CLOCKTYPE_PCLK1 | RCC_CLOCKTYPE_PCLK2);
#ifdef HSI
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_HSI;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV_SETTING;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV_SETTING;
  HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_0);
  
  /* Now the MSI can be turned off */
  CLEAR_BIT(RCC->CR, RCC_CR_MSION);
  
  /* HSI is configured to provide clock to the LPUART */
  PeriphClkInit.PeriphClockSelection = RCC_PERIPHCLK_LPUART1;
  PeriphClkInit.Lpuart1ClockSelection = RCC_LPUART1CLKSOURCE_HSI;
  HAL_RCCEx_PeriphCLKConfig(&PeriphClkInit);  
#else /* HSI */
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_MSI;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV_SETTING;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV_SETTING;
  HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_0);
  
  /* LSE is configured to provide clock to the LPUART */
  PeriphClkInit.PeriphClockSelection = RCC_PERIPHCLK_LPUART1;
  PeriphClkInit.Lpuart1ClockSelection = RCC_LPUART1CLKSOURCE_LSE;
  HAL_RCCEx_PeriphCLKConfig(&PeriphClkInit);  
#endif /* HSI */  
}

/**
  * @brief  System Power Configuration
  *         The system Power is configured.
  * @param  None
  * @retval None
  */
static void SystemPower_Config(void)
{
  GPIO_InitTypeDef GPIO_InitStructure;

#ifdef LPRUN
  __HAL_PWR_VOLTAGESCALING_CONFIG(PWR_CR_VOS_1);
#else /* LPRUN */
  __HAL_PWR_VOLTAGESCALING_CONFIG(PWR_CR_VOS_CONF);
#endif /* LPRUN */

  /* Enable Ultra low power mode*/
  HAL_PWREx_EnableUltraLowPower();

  /* Enable the fast wake up from Ultra low power mode*/
  HAL_PWREx_EnableFastWakeUp();

  /* Select HSI as system clock source after Wake Up from Stop mode */
#ifdef HSI
  __HAL_RCC_WAKEUPSTOP_CLK_CONFIG(RCC_STOP_WAKEUPCLOCK_HSI);
#else /* HSI */
  __HAL_RCC_WAKEUPSTOP_CLK_CONFIG(RCC_STOP_WAKEUPCLOCK_MSI);
#endif /* HSI */

  /* Enable GPIOs clock */
  __HAL_RCC_GPIOA_CLK_ENABLE();
  __HAL_RCC_GPIOB_CLK_ENABLE();
  __HAL_RCC_GPIOC_CLK_ENABLE();
  __HAL_RCC_GPIOD_CLK_ENABLE();
  __HAL_RCC_GPIOH_CLK_ENABLE();

  /* Configure all GPIO port pins in Analog Input mode (floating input trigger OFF) */
  GPIO_InitStructure.Pin = GPIO_PIN_All;
  GPIO_InitStructure.Mode = GPIO_MODE_ANALOG;
  GPIO_InitStructure.Pull = GPIO_NOPULL;
#ifdef DEBUG_OFF
  HAL_GPIO_Init(GPIOA, &GPIO_InitStructure);
#endif /* DEBUG_OFF */
  HAL_GPIO_Init(GPIOC, &GPIO_InitStructure);
  HAL_GPIO_Init(GPIOD, &GPIO_InitStructure);
  HAL_GPIO_Init(GPIOH, &GPIO_InitStructure);
  
  GPIO_InitStructure.Pin = ~(UARTx_TX_PIN | UARTx_RX_PIN);
  HAL_GPIO_Init(GPIOB, &GPIO_InitStructure);

  /* Disable GPIOs clock */
  __HAL_RCC_GPIOA_CLK_DISABLE();  
  __HAL_RCC_GPIOB_CLK_DISABLE();
  __HAL_RCC_GPIOC_CLK_DISABLE();
  __HAL_RCC_GPIOD_CLK_DISABLE();
  __HAL_RCC_GPIOH_CLK_DISABLE();
}

/**
  * @brief Send an amount of data in blocking mode - simplified version
  * @param huart: uart handle
  * @param pData: pointer to data buffer
  * @param Size: amount of data to be sent
  * @retval HAL status
  */
__ramfunc HAL_StatusTypeDef HAL_UART_TransmitFast(UART_HandleTypeDef *huart, uint8_t *pData, uint16_t Size)
{
  if ((huart->State == HAL_UART_STATE_READY) || (huart->State == HAL_UART_STATE_BUSY_RX))
  {
    /* check parameters */
    if ((pData == NULL ) || (Size == 0))
    {
      return  HAL_ERROR;
    }

    /* Process Locked */
    __HAL_LOCK(huart);

    huart->ErrorCode = HAL_UART_ERROR_NONE;
    /* Check if a non-blocking receive process is ongoing or not */
    if (huart->State == HAL_UART_STATE_BUSY_RX)
    {
      huart->State = HAL_UART_STATE_BUSY_TX_RX;
    }
    else
    {
      huart->State = HAL_UART_STATE_BUSY_TX;
    }

    huart->TxXferSize = Size;
    huart->TxXferCount = Size;
    while (huart->TxXferCount > 0)
    {
      if ( (huart->Instance->ISR & UART_FLAG_TXE) != 0 )
      {
        huart->Instance->TDR = *pData++;
        huart->TxXferCount--;
      }
#ifdef TXSLEEP
      __WFE();
#endif /* TXSLEEP */
    }

    /* Check if a non-blocking receive Process is ongoing or not */
    if (huart->State == HAL_UART_STATE_BUSY_TX_RX)
    {
      huart->State = HAL_UART_STATE_BUSY_RX;
    }
    else
    {
      huart->State = HAL_UART_STATE_READY;
    }

    while ( ( huart->Instance->ISR & UART_FLAG_TC ) == 0 )
    {}

    /* Process Unlocked */
    __HAL_UNLOCK(huart);

    return HAL_OK;
  }
  else
  {
    return HAL_BUSY;
  }
}

/**
  * @brief Receive an amount of data in blocking mode - simplified version
  * @param huart: uart handle
  * @param pData: pointer to data buffer
  * @param Size: amount of data to be received
  * @retval HAL status
  */
__ramfunc HAL_StatusTypeDef HAL_UART_ReceiveFast(UART_HandleTypeDef *huart, uint8_t *pData, uint16_t Size)
{
  /* check parameters */
  if ((pData == NULL ) || (Size == 0))
  {
    return  HAL_ERROR;
  }
  
  /* Process Locked */
  __HAL_LOCK(huart);

  huart->RxXferSize = Size;
  huart->RxXferCount = Size;

  SET_BIT(huart->Instance->CR1, USART_CR1_RE);

  /* as long as data have to be received */
  while (huart->RxXferCount > 0)
  {
    if ( (huart->Instance->ISR & UART_FLAG_RXNE) != 0 )
    {
      *pData++ = (uint8_t)huart->Instance->RDR;
      huart->RxXferCount--;
    }
#ifdef RXSLEEP
    __WFE();
#endif /* RXSLEEP */
  }

  CLEAR_BIT(huart->Instance->CR1, USART_CR1_RE);

  /* Check if a non-blocking transmit Process is ongoing or not */
  if (huart->State == HAL_UART_STATE_BUSY_TX_RX)
  {
    huart->State = HAL_UART_STATE_BUSY_TX;
  }
  else
  {
    huart->State = HAL_UART_STATE_READY;
  }
  /* Process Unlocked */
  __HAL_UNLOCK(huart);

  return HAL_OK;
}

/**
  * @brief  UART error callbacks
  * @param  huart: UART handle
  * @note   This example shows a simple way to report transfer error, and you can
  *         add your own implementation.
  * @retval None
  */
void HAL_UART_ErrorCallback(UART_HandleTypeDef *huart)
{
  while (1)
  {}
}

/**
  * @brief  Compares two buffers.
  * @param  pBuffer1, pBuffer2: buffers to be compared.
  * @param  BufferLength: buffer's length
  * @retval 0  : pBuffer1 identical to pBuffer2
  *         >0 : pBuffer1 differs from pBuffer2
  */
__ramfunc static uint16_t Buffercmp(uint8_t* pBuffer1, uint8_t* pBuffer2, uint16_t BufferLength)
{
  uint16_t retval = 0;

  while ((BufferLength--) && (retval == 0))
  {
    if (pBuffer1[BufferLength] != pBuffer2[BufferLength])
    {
      retval = BufferLength + 1;
    }
  }

  return retval;
}

/**
  * @brief  This function is executed in case of error occurrence.
  * @param  None
  * @retval None
  */
static void Error_Handler(void)
{
  while (1)
  {}
}

#ifdef  USE_FULL_ASSERT

/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t* file, uint32_t line)
{
  /* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */

  /* Infinite loop */
  while (1)
  {}
}
#endif /* USE_FULL_ASSERT */

/**
  * @}
  */

/**
  * @}
  */

/************************ (C) COPYRIGHT STMicroelectronics *****END OF FILE****/
