/**
  ******************************************************************************
  * @file    Project/STM32L0_Internal_RC_Oscillators_Calibration/Src/lsimeasurement.c
  * @author  MCD Application Team
  * @version V0.1.0
  * @date    17-December-2014
  * @brief   This file provides all the LSI Measurement firmware functions.
  ******************************************************************************
  * @attention
  *
  * <h2><center>&copy; COPYRIGHT 2014 STMicroelectronics</center></h2>
  *
  * Licensed under MCD-ST Liberty SW License Agreement V2, (the "License");
  * You may not use this file except in compliance with the License.
  * You may obtain a copy of the License at:
  *
  *        http://www.st.com/software_license_agreement_liberty_v2
  *
  * Unless required by applicable law or agreed to in writing, software
  * distributed under the License is distributed on an "AS IS" BASIS,
  * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
  * See the License for the specific language governing permissions and
  * limitations under the License.
  *
  ******************************************************************************
  */

/* Includes ------------------------------------------------------------------*/
#include "main.h"

/* Private typedef -----------------------------------------------------------*/
/* Private define ------------------------------------------------------------*/

#define LSI_TIMx_COUNTER_PRESCALER  ((uint32_t)0) /* TIMx counter is divided by 0 + 1 = 1 */
/* The signal in input capture is not divided */
#define LSI_TIMx_IC_DIVIDER         TIM_ICPSC_DIV1

#define LSI_NUMBER_OF_LOOPS       ((uint32_t)10)

/* Connect GPIO to TIMx Input Capture 1 */
#define LSI_Timer_ConnectInput()  do {                               \
    HAL_RCC_MCOConfig(RCC_MCO1, RCC_MCO1SOURCE_LSI, RCC_MCODIV_16); \
    HAL_TIMEx_RemapConfig(&TimHandle, TIM21_TI1_MCO);        \
  } while(0)

/* Private macro -------------------------------------------------------------*/
/* Private variables ---------------------------------------------------------*/
/* Private function prototypes -----------------------------------------------*/
void LSI_TIMx_Config(void);
void LSI_CLK_Config(void);
/* Private functions ---------------------------------------------------------*/

/** @addtogroup STM32L0xx_AN4631
  * @{
  */
	
/**
  * @brief  Measures the LSI clock frequency using TIMx capture interrupt.
  * @param  InternOscFrequency: The system clock source value.
  *         In case of using HSI16 oscillator as system clock source:
  *           InternOscFrequency should be 8000000 (or a more accurate value).
  *         In case of using another oscillator as system clock source:
  *           InternOscFrequency should correspond to the selected range (or a more accurate value).
  * @retval The LSI frequency value.
  */
uint16_t LSI_FreqMeasure(uint32_t InternOscFrequency)
{
  uint32_t measuredfrequency = 0;
  uint32_t loopcounter = 0;

  /* Configure CLK for LSI measurement process */
  LSI_CLK_Config();

  /* Configure TIMx for LSI measurement process */
  LSI_TIMx_Config();

  /* Reset counter */
  loopcounter = 0;

  /**************************** START of LSI Measurement **********************/
  while (loopcounter <= LSI_NUMBER_OF_LOOPS)
  {
    CaptureState = CAPTURE_START;

    /* Enable capture channel y interrupt */
    HAL_TIM_IC_Start_IT(&TimHandle, TIM_CHANNEL_y);

    /* Enable the TIMx IRQ channel */
    HAL_NVIC_EnableIRQ(TIMx_IRQn);

    /* Wait for end of capture: two consecutive captures */
    while (CaptureState != CAPTURE_COMPLETED);

    /* Disable IRQ channel */
    HAL_NVIC_DisableIRQ(TIMx_IRQn);

    /* Disable TIMx */
    HAL_TIM_IC_Stop_IT(&TimHandle, TIM_CHANNEL_y);

    if (loopcounter != 0)
    {
      /* Compute the frequency value: multiplying by 16 is due to MCO settings */
			/* Input capture divider = 1, Counter prescaler = 1 */
      /* Then add the current frequency to previous accumulation */
      measuredfrequency += ((uint32_t) 16 * (InternOscFrequency / Capture));
    }

    /* Increment counter */
    loopcounter++;
  }
  /**************************** END of LSI Measurement ************************/

  /* Compute the average of LSI frequency value */
  measuredfrequency = (uint16_t) (measuredfrequency / LSI_NUMBER_OF_LOOPS);

  /* Return the LSI frequency */
  return (uint16_t)(measuredfrequency);
}

/**
  * @brief  Configures LSI
  * @param  None.
  * @retval None.
  */
void LSI_CLK_Config(void)
{
  RCC_OscInitTypeDef osc_init;

  /* Enable LSI Oscillator */
  osc_init.OscillatorType = RCC_OSCILLATORTYPE_LSI;
  osc_init.LSIState = RCC_LSI_ON;
  osc_init.PLL.PLLState = RCC_PLL_NONE;
  if (HAL_RCC_OscConfig(&osc_init) != HAL_OK)
  {
    Error_Handler();
  }
}

/**
  * @brief  Configures the TIM x channel 1 in input capture to measure the LSI frequency.
  * @param  None.
  * @retval None.
  */
void LSI_TIMx_Config(void)
{
  TIM_IC_InitTypeDef      ic_config; /* Timer Input Capture Configuration Structure declaration */

  /* Set TIMx instance */
  TimHandle.Instance = TIMx;

  /* Enable TIMx clock */
  __TIMx_CLK_ENABLE();

  /* Reset TIMx registers */
  HAL_TIM_IC_DeInit(&TimHandle);

  /* Connect input signal */
  LSI_Timer_ConnectInput();

  /* TIMx configuration: Input Capture mode ---------------------
     The LSI clock is connected to TIMx CH1
     The Rising edge is used as active edge,
     The TIMx CCR1 is used to compute the frequency value 
  ------------------------------------------------------------ */
  TimHandle.Init.Period            = 0xFFFF;
  TimHandle.Init.Prescaler         = LSI_TIMx_COUNTER_PRESCALER;
  TimHandle.Init.ClockDivision     = 0;
  TimHandle.Init.CounterMode       = TIM_COUNTERMODE_UP;
  if (HAL_TIM_IC_Init(&TimHandle) != HAL_OK)
  {
    /* Initialization Error */
    Error_Handler();
  }

  /* Configure the Input Capture of channel y */
  ic_config.ICPolarity  = TIM_ICPOLARITY_RISING;
  ic_config.ICSelection = TIM_ICSELECTION_DIRECTTI;
  ic_config.ICPrescaler = LSI_TIMx_IC_DIVIDER;
  ic_config.ICFilter    = 0;
  if (HAL_TIM_IC_ConfigChannel(&TimHandle, &ic_config, TIM_CHANNEL_y) != HAL_OK)
  {
    /* Configuration Error */
    Error_Handler();
  }

  /* Configure the NVIC for TIMx */
  HAL_NVIC_SetPriority(TIMx_IRQn, 0, 1);

  /* Disable the TIMx global Interrupt */
  HAL_NVIC_DisableIRQ(TIMx_IRQn);
}

/**
  * @}
  */

/************************ (C) COPYRIGHT STMicroelectronics *****END OF FILE****/
