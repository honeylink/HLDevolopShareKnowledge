/**
  ******************************************************************************
  * @file    Project/STM32L0_Internal_RC_Oscillators_Calibration/Src/hsi48.c
  * @author  MCD Application Team
  * @version V0.1.0
  * @date    17-December-2014
  * @brief   This file provides all the HSI48 measurement and calibration firmware functions.
  ******************************************************************************
  * @attention
  *
  * <h2><center>&copy; COPYRIGHT 2014 STMicroelectronics</center></h2>
  *
  * Licensed under MCD-ST Liberty SW License Agreement V2, (the "License");
  * You may not use this file except in compliance with the License.
  * You may obtain a copy of the License at:
  *
  *        http://www.st.com/software_license_agreement_liberty_v2
  *
  * Unless required by applicable law or agreed to in writing, software
  * distributed under the License is distributed on an "AS IS" BASIS,
  * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
  * See the License for the specific language governing permissions and
  * limitations under the License.
  *
  ******************************************************************************
  */

/* Includes ------------------------------------------------------------------*/
#include "main.h"
#include "usbd_core.h"
#include "usbd_desc.h"
#include "usbd_dfu.h"
#include "usbd_dfu_flash.h"


/* Private typedef -----------------------------------------------------------*/
/* Private define ------------------------------------------------------------*/

/* Choose source of reference signal for CRS  */
#define CRS_USE_USB_SOF
//#define CRS_USE_GPIO


#define HSI48_TIMER_USE_REFERENCE_HSI48
//#define HSI48_TIMER_USE_REFERENCE_GPIO

#if !defined  (HSI48_VALUE) 
	#define HSI48_VALUE 								((uint32_t)48000000) /* Value of the Internal High Speed oscillator for USB in Hz.
                                             The real value may vary depending on the variations
                                             in voltage and temperature.  */
#endif /* HSI48_VALUE */
#ifdef CRS_USE_USB_SOF
	#define CRS_SOURCE_FREQUENCY 				((uint32_t)1000) /* USB HS frame is generated every 1ms*/
#elif defined CRS_USE_GPIO
	#define CRS_SOURCE_FREQUENCY 				((uint32_t)1000) /* Input frequency connected to GPIO */
#endif /* CRS_USE_USB_SOF  */

/* Bit position in register */
#define CRS_CFGR_FELIM_BITNUMBER      ((uint32_t)16)
#define CRS_CR_TRIM_BITNUMBER         ((uint32_t)8)
#define CRS_ISR_FECAP_BITNUMBER       ((uint32_t)16)

#define TRIMMING_STEP          				((uint32_t)67)			/* in kHz */
#define TARGET_FREQUENCY         			((uint32_t)48000)   /* in kHz */

#define HSI48_TIMEOUT          				((uint32_t)0xFFFFFF)

/* Private macro -------------------------------------------------------------*/
/* Private variables ---------------------------------------------------------*/
/* Variable to save SYNC status*/
__IO uint32_t CRSSyncStatus = 0;

/* Private function prototypes -----------------------------------------------*/
void HAL_RCCEx_CRSConfigManual(RCC_CRSInitTypeDef *pInit);
void HSI48_CRS_Init(void);
void HSI48_SystemClock_Config(void);

/* Private functions ---------------------------------------------------------*/

/** @addtogroup STM32L0xx_AN4631
  * @{
  */

/**
  * @brief  Handle CRS interruption
  * @param  none
  * @retval none
  */
void CRS_HandlerIT(void)
{
  /* Check CRS SYNCOK flag  */
  if ((__HAL_RCC_CRS_GET_FLAG(RCC_CRS_FLAG_SYNCOK)) && (__HAL_RCC_CRS_GET_IT_SOURCE(RCC_CRS_IT_SYNCOK)))
  {

    /* Power off LED4*/
    BSP_LED_Off(LED4);

    CRSSyncStatus = 0;
    /* Clear CRS SYNC event OK bit */
    __HAL_RCC_CRS_CLEAR_IT(RCC_CRS_FLAG_SYNCOK);
  }

  /* Check CRS SYNCWARN flag  */
  if ((__HAL_RCC_CRS_GET_FLAG(RCC_CRS_FLAG_SYNCWARN)) && (__HAL_RCC_CRS_GET_IT_SOURCE(RCC_CRS_IT_SYNCWARN)))
  {
    /* Power on LED4*/
    BSP_LED_On(LED4);

    CRSSyncStatus = 1;

    /* Clear CRS SYNCWARN bit */
    __HAL_RCC_CRS_CLEAR_IT(RCC_CRS_FLAG_SYNCWARN);
  }

  /* Check CRS Error flag  */
  if ((__HAL_RCC_CRS_GET_FLAG(RCC_CRS_FLAG_SYNCERR)) && (__HAL_RCC_CRS_GET_IT_SOURCE(RCC_CRS_IT_SYNCERR)))
  {
    /* Power off LED4*/
    BSP_LED_Off(LED4);

    CRSSyncStatus = 2;

    /* Clear CRS Error bit */
    __HAL_RCC_CRS_CLEAR_IT(RCC_CRS_FLAG_SYNCERR);
  }

  /* Check CRS SYNC Missed flag  */
  if ((__HAL_RCC_CRS_GET_FLAG(RCC_CRS_FLAG_SYNCMISS)) && (__HAL_RCC_CRS_GET_IT_SOURCE(RCC_CRS_IT_ERR)))
  {
    /* Power off LED4*/
    BSP_LED_Off(LED4);

    CRSSyncStatus = 2;

    /* Clear CRS SYNC Missed bit */
    __HAL_RCC_CRS_CLEAR_IT(RCC_CRS_FLAG_SYNCMISS);
  }

  /* Check CRS Expected SYNC flag  */
  if ((__HAL_RCC_CRS_GET_FLAG(RCC_CRS_FLAG_ESYNC)) && (__HAL_RCC_CRS_GET_IT_SOURCE(RCC_CRS_IT_ESYNC)))
  {
    /* frequency error counter reached a zero value */
    __HAL_RCC_CRS_CLEAR_IT(RCC_CRS_FLAG_ESYNC);
  }
}

/**
  * @brief  CRS initialization
  * @param  none
  * @retval none
  */
void HSI48_CRS_Init(void)
{
  GPIO_InitTypeDef      gpio_init;
  RCC_OscInitTypeDef     osc_init =  {0};
  RCC_CRSInitTypeDef     crs_init = {0};
  RCC_PeriphCLKInitTypeDef  periphclock_init;

  HAL_RCC_GetOscConfig(&osc_init);

  /* Enable HSI Oscillator to be used as System clock source
     Enable HSI48 Oscillator to be used as USB clock source */
  osc_init.OscillatorType = RCC_OSCILLATORTYPE_HSI | RCC_OSCILLATORTYPE_HSI48;
  osc_init.HSIState = RCC_HSI_ON;
  osc_init.HSI48State = RCC_HSI48_ON;
  HAL_RCC_OscConfig(&osc_init);

  /* Select HSI48 as USB clock source */
  periphclock_init.PeriphClockSelection = RCC_PERIPHCLK_USB;
  periphclock_init.UsbClockSelection = RCC_USBCLKSOURCE_HSI48;
  HAL_RCCEx_PeriphCLKConfig(&periphclock_init);


  /* Enable CRS clock */
  __HAL_RCC_CRS_CLK_ENABLE();

  crs_init.Polarity              = RCC_CRS_SYNC_POLARITY_FALLING;
#if defined CRS_USE_USB_SOF
  /* Enable USB pins */
  /* GPIOA Clock Enable */
  __HAL_RCC_GPIOA_CLK_ENABLE();

  /* Configue the USB pins in input mode */
  gpio_init.Pin = GPIO_PIN_11 | GPIO_PIN_12;
  gpio_init.Mode = GPIO_MODE_INPUT;
  gpio_init.Speed = GPIO_SPEED_HIGH;
  gpio_init.Pull = GPIO_NOPULL;
  HAL_GPIO_Init(GPIOA, &gpio_init);

  /* Start USB communication */
  __HAL_RCC_USB_CLK_ENABLE();
  /* Force USB Reset */
  USB->CNTR = 0x01;
  /* Clear Force USB Reset bit */
  USB->CNTR = 0;
  /* Clear pending interrupts*/
  USB->ISTR = 0;
  /* Start USB communication */
  USB->BCDR |= USB_BCDR_DPPU;

	/* Configue CRS */
  crs_init.Prescaler             = RCC_CRS_SYNC_DIV1;
  crs_init.Source                = RCC_CRS_SYNC_SOURCE_USB;
  crs_init.ReloadValue           = __HAL_RCC_CRS_CALCULATE_RELOADVALUE(HSI48_VALUE, CRS_SOURCE_FREQUENCY);
  crs_init.ErrorLimitValue       = RCC_CRS_ERRORLIMIT_DEFAULT;
#elif defined CRS_USE_GPIO  /* not CRS_USE_USB_SOF */
  __HAL_RCC_GPIOA_CLK_ENABLE();

  /* Configue the USB pins in input mode */
  gpio_init.Pin = GPIO_PIN_8;
  gpio_init.Mode = GPIO_MODE_AF_PP;
  gpio_init.Speed = GPIO_SPEED_HIGH;
  gpio_init.Pull = GPIO_NOPULL;
  gpio_init.Alternate = GPIO_AF2_USB;
  HAL_GPIO_Init(GPIOA, &gpio_init);

  crs_init.Prescaler             = RCC_CRS_SYNC_DIV1;
  crs_init.Source                = RCC_CRS_SYNC_SOURCE_GPIO;
  crs_init.ReloadValue           = __HAL_RCC_CRS_CALCULATE_RELOADVALUE(HSI48_VALUE, CRS_SOURCE_FREQUENCY);
  crs_init.ErrorLimitValue       = RCC_CRS_ERRORLIMIT_DEFAULT;
#endif   /* CRS_USE_USB_SOF */

  /* Keep original trimming value */
  /* Note: setting this value to demonstates CRS functionality in full range */
  crs_init.HSI48CalibrationValue = (CRS->CR & CRS_CR_TRIM) >> CRS_CR_TRIM_BITNUMBER;

  /* Start automatic synchronization*/
  HAL_RCCEx_CRSConfigManual(&crs_init);

  /* Enable RCC_CRS Interruptions */
  __HAL_RCC_CRS_ENABLE_IT(RCC_CRS_IT_SYNCOK | RCC_CRS_IT_SYNCWARN | RCC_CRS_IT_ERR | RCC_CRS_IT_ESYNC);
}

/**
  * @brief  System Clock Configuration for HSI48 measurement
  *         The system Clock is configured as follow :
  *            System Clock source            = PLL (HSI16)
  *            SYSCLK(Hz)                     = 32000000
  *            HCLK(Hz)                       = 32000000
  *            AHB Prescaler                  = 1
  *            APB1 Prescaler                 = 1
  * @param  None
  * @retval None
  */
void HSI48_SystemClock_Config(void)
{
  RCC_ClkInitTypeDef clk_init;
  RCC_OscInitTypeDef osc_init;

  /* Enable HSE Oscillator and Activate PLL with HSE as source */
  osc_init.OscillatorType = RCC_OSCILLATORTYPE_HSI;
  osc_init.HSEState = RCC_HSE_ON;
  osc_init.PLL.PLLState = RCC_PLL_ON;
  osc_init.PLL.PLLSource = RCC_PLLSOURCE_HSI;
  osc_init.PLL.PLLMUL = RCC_PLLMUL_4;
  osc_init.PLL.PLLDIV = RCC_PLLDIV_2;
  if (HAL_RCC_OscConfig(&osc_init) != HAL_OK)
  {
    Error_Handler();
  }

  /* Select PLL as system clock source and configure the HCLK, PCLK1 clocks dividers */
  clk_init.ClockType = (RCC_CLOCKTYPE_SYSCLK | RCC_CLOCKTYPE_HCLK | RCC_CLOCKTYPE_PCLK1);
  clk_init.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
  clk_init.AHBCLKDivider = RCC_SYSCLK_DIV1;
  clk_init.APB1CLKDivider = RCC_HCLK_DIV1;
  clk_init.APB2CLKDivider = RCC_HCLK_DIV1;
  if (HAL_RCC_ClockConfig(&clk_init, FLASH_LATENCY_1) != HAL_OK)
  {
    Error_Handler();
  }
}

/**
  * @brief  Initialize CRS module
  * @param  pInit Pointer on RCC_CRSInitTypeDef structure
  * @retval None
  */
void HAL_RCCEx_CRSConfigManual(RCC_CRSInitTypeDef *pInit)
{
  /* CONFIGURATION */
  /* Before configuration, reset CRS registers to their default values*/
  __HAL_RCC_CRS_FORCE_RESET();
  __HAL_RCC_CRS_RELEASE_RESET();

  /* Configure Synchronization input */
  /* Clear SYNCDIV[2:0], SYNCSRC[1:0] & SYNCSPOL bits */
  CRS->CFGR &= ~(CRS_CFGR_SYNCDIV | CRS_CFGR_SYNCSRC | CRS_CFGR_SYNCPOL);

  /* Set the CRS_CFGR_SYNCDIV[2:0] bits according to Prescaler value */
  CRS->CFGR |= pInit->Prescaler;

  /* Set the SYNCSRC[1:0] bits according to Source value */
  CRS->CFGR |= pInit->Source;

  /* Set the SYNCSPOL bits according to Polarity value */
  CRS->CFGR |= pInit->Polarity;

  /* Configure Frequency Error Measurement */
  /* Clear RELOAD[15:0] & FELIM[7:0] bits*/
  CRS->CFGR &= ~(CRS_CFGR_RELOAD | CRS_CFGR_FELIM);

  /* Set the RELOAD[15:0] bits according to ReloadValue value */
  CRS->CFGR |= pInit->ReloadValue;

  /* Set the FELIM[7:0] bits according to ErrorLimitValue value */
  CRS->CFGR |= (pInit->ErrorLimitValue << CRS_CFGR_FELIM_BITNUMBER);

  /* Adjust HSI48 oscillator smooth trimming */
  /* Clear TRIM[5:0] bits */
  CRS->CR &= ~CRS_CR_TRIM;

  /* Set the TRIM[5:0] bits according to RCC_CRS_HSI48CalibrationValue value */
  CRS->CR |= (pInit->HSI48CalibrationValue << CRS_CR_TRIM_BITNUMBER);

}

/**
  * @brief  HSI48 manual synchronization using polling mode
  * @brief  After SYNCOK state is reached, automatic calibration is activated
  * @param  None
  * @retval If successful then frequency error of HSI oscillator. Otherwise ERROR
  */
uint32_t HSI48_ManualTrimming(void)
{

  uint32_t freqerror, reload;
  uint32_t timeout = HSI48_TIMEOUT;

  /* CRS initialization (enable HSI48 and LSE oscillators and then enable CRS clock */
  HSI48_CRS_Init();

  /* Get RELOAD value for frequency error computation */
  reload = CRS->CFGR & CRS_CFGR_RELOAD;

  /* Disable frequency error counter */
  __HAL_RCC_CRS_DISABLE_FREQ_ERROR_COUNTER();

  /* Stop RCC_CRS Interrupts */
  __HAL_RCC_CRS_DISABLE_IT(RCC_CRS_IT_SYNCOK | RCC_CRS_IT_SYNCWARN | RCC_CRS_IT_ERR | RCC_CRS_IT_ESYNC);

  /* Enable frequency error counter */
  __HAL_RCC_CRS_ENABLE_FREQ_ERROR_COUNTER();

  /* Wait for end of calibration */
  while (((CRS->ISR & (RCC_CRS_IT_ERR | RCC_CRS_IT_SYNCWARN | RCC_CRS_IT_SYNCOK))  == 0) && (timeout != 0))
  {
    if (--timeout == 0)
    {
      return ERROR;
    }
  }

  /* Process error synchro or trimming error */
  /* Act only if there is error or warning  */
  while ((CRS->ISR & (RCC_CRS_IT_ERR | RCC_CRS_IT_SYNCWARN)) != 0)
  {
    /* Calculate difference from requested frequency in trimming steps (67kHz) */
    freqerror  = (((CRS->ISR & CRS_ISR_FECAP) >> CRS_ISR_FECAP_BITNUMBER) * TARGET_FREQUENCY / reload) / TRIMMING_STEP;

    /* Depending error direction trim frequency */
    if ((CRS->ISR & CRS_ISR_FEDIR) == RCC_CRS_FREQERRORDIR_DOWN)
    {
      CRS->CR += (freqerror << CRS_CR_TRIM_BITNUMBER);
    }
    else
    {
      CRS->CR -= (freqerror << CRS_CR_TRIM_BITNUMBER);
    }

    /* Clear error/warning bit to allow to see the measurement status */
    __HAL_RCC_CRS_CLEAR_IT(RCC_CRS_IT_ERR | RCC_CRS_IT_SYNCWARN);

    /* Wait for end of calibration */
    timeout = HSI48_TIMEOUT;
    while (((CRS->ISR & (RCC_CRS_IT_ERR | RCC_CRS_IT_SYNCWARN | RCC_CRS_IT_SYNCOK)) == 0) && (timeout != 0))
    {
      if (--timeout == 0)
      {
        return ERROR;
      }
    }
  }

  /* Enable RCC_CRS Interruptions */
  __HAL_RCC_CRS_ENABLE_IT(RCC_CRS_IT_SYNCOK | RCC_CRS_IT_SYNCWARN | RCC_CRS_IT_ERR | RCC_CRS_IT_ESYNC);

  /* Enable and set RCC/RCS Interrupt*/
  HAL_NVIC_SetPriority(RCC_IRQn, 0x03, 0x00);
  HAL_NVIC_EnableIRQ(RCC_IRQn);

  /* Run automatic triming mode */
  __HAL_RCC_CRS_ENABLE_AUTOMATIC_CALIB();

  /* Return final frequency */
  freqerror = TARGET_FREQUENCY;

  if ((CRS->ISR & RCC_CRS_FREQERRORDIR_DOWN) == 0)
  {
    freqerror += (((CRS->ISR & CRS_ISR_FECAP) >> CRS_ISR_FECAP_BITNUMBER) * TARGET_FREQUENCY / reload);
  }
  else
  {
    freqerror -= (((CRS->ISR & CRS_ISR_FECAP) >> CRS_ISR_FECAP_BITNUMBER) * TARGET_FREQUENCY / reload);
  }

	/* frequency error in MHz */
  return (freqerror * 1000);
}

/**
  * @brief  Measures the HSI48 clock frequency using TIM14 capture interrupt.
  * @param  The system clock source value:
  *         In case of using HSI48 oscillator as system clock source:
  *         InternOscFrequency should be 16000000 (or a more accurate value.
  *         In case of using HSI oscillator as system clock source:
  *         InternOscFrequency should correspond to the selected range (or a more accurate value).
  * @retval The HSI48 frequency value.
  */
uint32_t HSI48_FreqMeasure(void)
{

  uint32_t freqvalue, reload;
  uint32_t  timeout = HSI48_TIMEOUT;

  /* CRS initialization (enable HSI48 and LSE oscillators and then enable CRS clock */
  HSI48_CRS_Init();

  /* Get RELOAD value for frequency error computation */
  reload = CRS->CFGR & CRS_CFGR_RELOAD;

  /* Disable frequency error counter */
  __HAL_RCC_CRS_DISABLE_FREQ_ERROR_COUNTER();

  /* Stop RCC_CRS Interrupts */
  __HAL_RCC_CRS_DISABLE_IT(RCC_CRS_IT_SYNCOK | RCC_CRS_IT_SYNCWARN | RCC_CRS_IT_ERR | RCC_CRS_IT_ESYNC);

  /* Enable frequency error counter */
  __HAL_RCC_CRS_ENABLE_FREQ_ERROR_COUNTER();

  /* Wait for end of calibration */
  while (((CRS->ISR & (RCC_CRS_IT_ERR | RCC_CRS_IT_SYNCWARN | RCC_CRS_IT_SYNCOK))  == 0) && (timeout != 0))
  {
    if (--timeout == 0)
    {
      return ERROR;
    }
  }

  /* Return final frequency */
  freqvalue = TARGET_FREQUENCY;

  if ((CRS->ISR & RCC_CRS_FREQERRORDIR_DOWN) == 0)
  {
    freqvalue += (((CRS->ISR & CRS_ISR_FECAP) >> CRS_ISR_FECAP_BITNUMBER) * TARGET_FREQUENCY / reload);
  }
  else
  {
    freqvalue -= (((CRS->ISR & CRS_ISR_FECAP) >> CRS_ISR_FECAP_BITNUMBER) * TARGET_FREQUENCY / reload);
  }

  /* frequency error in MHz */
  return (freqvalue * 1000);
}

/**
  * @}
  */


/************************ (C) COPYRIGHT STMicroelectronics *****END OF FILE****/
