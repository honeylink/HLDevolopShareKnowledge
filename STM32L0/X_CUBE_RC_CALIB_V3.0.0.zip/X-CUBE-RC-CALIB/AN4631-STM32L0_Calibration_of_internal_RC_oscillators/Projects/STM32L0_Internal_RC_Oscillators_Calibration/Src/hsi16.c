/**
  ******************************************************************************
  * @file    Project/STM32L0_Internal_RC_Oscillators_Calibration/Src/hsi16.c
  * @author  MCD Application Team
  * @version V0.1.0
  * @date    17-December-2014
  * @brief   This file provides all the HSI measurement and calibration firmware functions.
  ******************************************************************************
  * @attention
  *
  * <h2><center>&copy; COPYRIGHT 2014 STMicroelectronics</center></h2>
  *
  * Licensed under MCD-ST Liberty SW License Agreement V2, (the "License");
  * You may not use this file except in compliance with the License.
  * You may obtain a copy of the License at:
  *
  *        http://www.st.com/software_license_agreement_liberty_v2
  *
  * Unless required by applicable law or agreed to in writing, software
  * distributed under the License is distributed on an "AS IS" BASIS,
  * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
  * See the License for the specific language governing permissions and
  * limitations under the License.
  *
  ******************************************************************************
  */

/* Includes ------------------------------------------------------------------*/
#include "main.h"

/* Private typedef -----------------------------------------------------------*/
/* Private define ------------------------------------------------------------*/
#ifdef USE_REFERENCE_LSE
#define HSI16_TIMx_COUNTER_PRESCALER   ((uint32_t)0)
/* The signal in input capture is divided by 8 */
#define HSI16_TIMx_IC_DIVIDER          TIM_ICPSC_DIV8

/* The LSE is divided by 8 => LSE/8 = 32768/8 = 4096 */
#define REFERENCE_FREQUENCY         ((uint32_t)4096) /*!< The reference frequency value in Hz */

/* Number of measurements in the loop */
#define HSI16_NUMBER_OF_LOOPS        ((uint32_t)10)

/* Connect LSE clock (through MCO) to TIMx Input Capture 1 */
#define HSI16_Timer_ConnectInput()   do {                              \
    HAL_TIMEx_RemapConfig(&TimHandle, TIM_TIMx_LSE);       \
  } while (0)
#else    /* not USE_REFERENCE_LSE */
/* If reference frequency is not the LSE and lower than 250 Hz,
the TIMx counter prescaler should be used.
Otherwise (the reference frequency is greater than 250 Hz),
the TIMx counter prescaler should be set to 0

For example, If reference frequency is 50 Hz, the counter prescaler should be 8.
In that case the minimum frequency (if HSI is system clock source) is 16MHz/(8*65535) ~ 31 Hz

If the reference frequency is lower than 31Hz, the counter prescaler should be
used regarding the reference frequency in input */

/* The reference frequency is 50 Hz (the signal in input capture is not divided) */
#define REFERENCE_FREQUENCY         ((uint32_t)1000) /* The reference frequency value in Hz */

#define HSI16_TIMx_COUNTER_PRESCALER   ((uint32_t)0x07) /* TIMx counter is divided by 7 + 1 = 8 */
/* The signal in input capture is not divided */
#define HSI16_TIMx_IC_DIVIDER          TIM_ICPSC_DIV1

/* Connect GPIO to TIMx Input Capture 1 */
#define HSI16_Timer_ConnectInput()   do {                        \
    HAL_TIMEx_RemapConfig(&TimHandle, TIM_TIMx_GPIO); \
  } while (0)

/* Number of measurements in the loop */
#define HSI16_NUMBER_OF_LOOPS        ((uint32_t)10)

#endif /* USE_REFERENCE_LSE */

/* Timeout to avoid endless loop */
#define HSI16_TIMEOUT          			((uint32_t)0xFFFFFF)
	
/* Get actual trimming settings of HSI16 */	
#define GET_HSI16_TRIMMING_VALUE() 	((RCC->ICSCR & RCC_ICSCR_HSITRIM) >> 8)	

/* Private macro -------------------------------------------------------------*/
/* Private variables ---------------------------------------------------------*/
/* Private function prototypes -----------------------------------------------*/
void HSI16_TIMx_ConfigForCalibration(void);
void HSI16_RCC_AdjustCalibrationValue(uint8_t InternOsc, uint8_t TrimmingValue);
uint32_t HSI16_FreqMeasure(void);
void HSI16_MeasurementInit(void);

/* Private functions ---------------------------------------------------------*/

/** @addtogroup STM32L0xx_AN4631
  * @{
  */

/**
  * @brief  Calibrates internal oscillators HSI to the minimum computed error.
  *         The system clock source is checked:
  *           - If HSI oscillator is used as system clock source, HSI is calibrated
  *             and the new HSI value is returned.
  *           - Otherwise function returns 0.
  * @param  None.
  * @retval The optimum computed frequency of HSI oscillator.
  *         Returning 0 means that the system clock source is not HSI.
  */
uint32_t HSI16_CalibrateMinError(void)
{
  uint32_t  measuredfrequency = 0;
  uint32_t  sysclockfrequency = 0;
  uint32_t  optimumfrequency = 0;
  uint32_t  frequencyerror = 0;
  uint32_t  optimumfrequencyerror = INITIAL_ERROR; /* Large value */
  uint32_t  numbersteps = 0;         /* Number of steps: size of trimming bits */
  uint32_t  trimmingvalue = 0;
  uint32_t  optimumcalibrationvalue = 0;

  /* Set measurement environment */
  HSI16_MeasurementInit();

  /* Get system clock frequency */
  sysclockfrequency = HAL_RCC_GetSysClockFreq();

  if (StartCalibration != 0)
  {
    /* HSI16TRIM is 5-bit length */
    numbersteps = 32; /* number of steps is 2^5 = 32 */
  }
  else
  {
    /* Without Calibration */
    numbersteps = 1;
  }

  /* Internal Osc frequency measurement for numbersteps */
  for (trimmingvalue = 0; trimmingvalue < numbersteps; trimmingvalue++)
  {
    if (StartCalibration != 0)
    {
      /* Set the Intern Osc trimming bits to trimmingvalue */
      HSI16_RCC_AdjustCalibrationValue(__HAL_RCC_GET_SYSCLK_SOURCE(), trimmingvalue);
    }

    /* Get actual frequency value */
    measuredfrequency = HSI16_FreqMeasure();

    if (StartCalibration != 0)
    {
      /* Compute current frequency error corresponding to the current trimming value:
      measured value is subtracted from the typical one */
      frequencyerror = ABS_RETURN((int32_t) (measuredfrequency - sysclockfrequency));

      /* Get the nearest frequency value to typical one */
      if (optimumfrequencyerror > frequencyerror)
      {
        optimumfrequencyerror = frequencyerror;
        optimumcalibrationvalue = trimmingvalue;
        optimumfrequency = measuredfrequency;
      }
    }
  }

  if (StartCalibration != 0)
  {
    /* Set trimming bits corresponding to the nearest frequency */
    HSI16_RCC_AdjustCalibrationValue(__HAL_RCC_GET_SYSCLK_SOURCE(), optimumcalibrationvalue);
    /* Return the intern oscillator frequency after calibration */
    return (optimumfrequency);
  }
  else
  {
    /* Return the intern oscillator frequency before calibration */
    return (measuredfrequency);
  }
}

/**
  * @brief  Calibrates the internal oscillator (HSI only) with the maximum allowed
  *         error value set by user.
  *         If this value was not found, this function sets the oscillator
  *         to default value.
  * @param  MaxAllowedError: maximum absolute value allowed of the HSI frequency
  *                          error given in Hz.
  * @param  Freq: returns value of calibrated frequency
  * @retval ErrorStatus:
  *            - SUCCESS: a frequency error =< MaxAllowedError was found.
  *            - ERROR: a frequency error =< MaxAllowedError was not found.
  */
ErrorStatus HSI16_CalibrateFixedError(uint32_t MaxAllowedError, uint32_t* Freq)
{
  uint32_t  measuredfrequency;
  uint32_t  frequencyerror = 0;
  uint32_t  sysclockfrequency = 0;
  uint32_t  trimmingindex = 0;
  uint32_t  trimmingvalue;
  uint32_t  numbersteps;
  int32_t   sign = 1;
  ErrorStatus calibrationstatus = ERROR;

  if (StartCalibration != 0)
  {
    /* HSI16TRIM is 5-bit length */
    numbersteps = 32; /* number of steps is 2^5 = 32 */
  }
  else
  {
    /* Without Calibration */
    numbersteps = 1;
  }

  /* Set measurement environment */
  HSI16_MeasurementInit();

  /* Get system clock frequency */
  sysclockfrequency = HAL_RCC_GetSysClockFreq();

  /* Start frequency measurement for current trimming value */
  measuredfrequency = 0;

  /* RC Frequency measurement for different values */
  for (trimmingindex = 0; trimmingindex < numbersteps; trimmingindex++)
  {
    /* Compute trimming value */
    trimmingvalue = trimmingvalue + (trimmingindex * sign);
    sign *= (-1);

    /* Set the HSI16TRIM register to trimmingvalue to be ready for measurement */
    __HAL_RCC_HSI_CALIBRATIONVALUE_ADJUST(trimmingvalue);

    /* Get actual frequency value */
    measuredfrequency = HSI16_FreqMeasure();

    /* Compute current frequency error corresponding to the current trimming value:
       measured value is subtracted from the typical one */
    frequencyerror = ABS_RETURN((int32_t) (measuredfrequency - sysclockfrequency));

    /* Check if frequency error is less or equal to value set by the user */
    if (frequencyerror <= MaxAllowedError)
    {
      calibrationstatus = SUCCESS; /* The calibration has succeed */
      break; /* stop searching and measurements for frequencies */
    }
  }

  /* Save the new HSI value */
  *Freq = measuredfrequency;

  /* If the frequency error set by the user was not found */
  if (calibrationstatus == ERROR)
  {
    /* Set the HSI16TRIM register to default value */
    __HAL_RCC_HSI_CALIBRATIONVALUE_ADJUST(numbersteps / 2);
  }

  /* Return the calibration status: ERROR or SUCCESS */
  return (calibrationstatus);
}

/**
  * @brief  For all possible trimming values change of frequency is measured
  * @retval None.
  */
void HSI16_GetCurve(void)
{
  uint32_t measuredfrequency;
  uint32_t trimmingindex = 0;
  uint32_t trimmingindexorig;
  uint32_t orig_frequency;
  uint32_t numbersteps;

  /* Set measurement environment */
  HSI16_MeasurementInit();

  if (StartCalibration != 0)
  {
    /* HSI16TRIM is 5-bit length */
    numbersteps = 32; /* number of steps is 2^5 = 32 */
  }
  else
  {
    /* Without Calibration */
    numbersteps = 1;
  }

  /* Keep original values */
  trimmingindexorig = GET_HSI16_TRIMMING_VALUE();
  orig_frequency = HSI16_FreqMeasure();

  /* RC Frequency measurement for different values */
  for (trimmingindex = 0; trimmingindex < numbersteps; trimmingindex++)
  {
    /* Set the HSI16TRIM register to trimmingvalue to be ready for measurement */
    __HAL_RCC_HSI_CALIBRATIONVALUE_ADJUST(trimmingindex);
    /* Start measuring Internal Oscillator frequency */
    measuredfrequency = HSI16_FreqMeasure();
    /* Compute current frequency error corresponding to the current trimming value:
      measured value is subtracted from the typical one */
    aFrequenceChangeTable[trimmingindex] =   ((int32_t)(measuredfrequency - orig_frequency));
  }

  /* Keep knowledge that curve exists */
  if (TrimmingCurveMeasured == 0)
  {
    TrimmingCurveMeasured = 1;
  }

  /* Set back the original frequency value */
  __HAL_RCC_HSI_CALIBRATIONVALUE_ADJUST(trimmingindexorig);
}

/**
 * @brief  Adjust calibration value (writing to trimming bits) of selected oscillator.
  * @param  Freq: pointer to an uint32_t variable that will contain the value
  *               of the internal oscillator frequency after calibration.
  * @retval ErrorStatus:
  *            - SUCCESS: successful calibration
  *            - ERROR: if frequency could not be calibrated
  */
ErrorStatus HSI16_CalibrateCurve(uint32_t* Freq)
{

  uint32_t measuredfrequency;
  uint32_t optimumcalibrationvalue;
  uint32_t i;
  uint32_t frequencyerror;
  uint32_t numbersteps = 32;
  uint32_t optimumfrequencyerror = INITIAL_ERROR; /* Large value */
  ErrorStatus returnvalue = ERROR;


  if (StartCalibration != 0)
  {
    /* HSI16TRIM is 5-bit length */
    numbersteps = 32; /* number of steps is 2^5 = 32 */
  }
  else
  {
    /* Without Calibration */
    numbersteps = 1;
  }

  /* Get position */
  measuredfrequency = HSI16_FreqMeasure();

  /* Find the closest difference */
  for (i = 0; i < numbersteps; i++)
  {
    frequencyerror = ABS_RETURN((int32_t) (HSI_VALUE - (int32_t)(measuredfrequency + aFrequenceChangeTable[i])));

    /* Get the nearest frequency value to typical one */
    if (frequencyerror < optimumfrequencyerror)
    {
      optimumfrequencyerror = frequencyerror;
      optimumcalibrationvalue = i;
    }
  }

  if (optimumfrequencyerror != INITIAL_ERROR)
  {
    __HAL_RCC_HSI_CALIBRATIONVALUE_ADJUST(optimumcalibrationvalue);
    /* Save the HSI measured value */
    *Freq = measuredfrequency + aFrequenceChangeTable[optimumcalibrationvalue];
    returnvalue = SUCCESS;
  }

  return returnvalue;
}

/**
  * @brief Measures actual value of HSI
  * @param  None.
  * @retval Actual HSI frequency
  */
uint32_t HSI16_FreqMeasure(void)
{
  uint32_t  measuredfrequency;
  uint32_t  loopcounter = 0;
  uint32_t  timeout = HSI16_TIMEOUT;

  /* Start frequency measurement for current trimming value */
  measuredfrequency = 0;
  loopcounter = 0;
  /* Start measuring Internal Oscillator frequency */
  while (loopcounter <= HSI16_NUMBER_OF_LOOPS)
  {
    CaptureState = CAPTURE_START;

    /* Enable capture 1 interrupt */
    HAL_TIM_IC_Start_IT(&TimHandle, TIM_CHANNEL_y);

    /* Enable the TIMx IRQ channel */
    HAL_NVIC_EnableIRQ(TIMx_IRQn);

    /* Wait for end of capture: two consecutive captures */
    while ((CaptureState != CAPTURE_COMPLETED) && (timeout != 0))
    {
      if (--timeout == 0)
      {
        return ERROR;
      }
    }

    /* Disable IRQ channel */
    HAL_NVIC_DisableIRQ(TIMx_IRQn);

    /* Disable TIMx */
    HAL_TIM_IC_Stop_IT(&TimHandle, TIM_CHANNEL_y);

    if (loopcounter != 0)
    {
      /* Compute the frequency (the Timer prescaler isn't included) */
      measuredfrequency += (uint32_t) (REFERENCE_FREQUENCY * Capture);
    }

    /* Increment loop counter */
    loopcounter++;
  }
  /* END of Measurement */

  /* Compute the average value corresponding the current trimming value */
  measuredfrequency = (uint32_t)((__HAL_GET_TIM_PRESCALER(&TimHandle) + 1) * (measuredfrequency / HSI16_NUMBER_OF_LOOPS));
  return measuredfrequency;
}

/**
  * @brief Configures all the necessary peripherals necessary from frequency calibration.
  * @param  None.
  * @retval None.
  */
void HSI16_MeasurementInit(void)
{
  SetSysClock_HSI16();

  /* Configure the GPIO ports before starting calibration process */
  GPIO_ConfigForCalibration();

  /* Configure clock before starting calibration process */
  CLK_ConfigForCalibration();

  /* Configure TIMx before starting calibration process */
  HSI16_TIMx_ConfigForCalibration();
}

/**
  * @brief Configures the TIMx in input capture to measure HSI frequency.
  * @param  None.
  * @retval None.
  */
void HSI16_TIMx_ConfigForCalibration(void)
{
  TIM_IC_InitTypeDef      ic_config; /* Timer Input Capture Configuration Structure declaration */

  /* Enable TIMx clock */
  __TIMx_CLK_ENABLE();

  /* Set TIMx instance */
  TimHandle.Instance = TIMx;

  /* Reset TIMx registers */
  HAL_TIM_IC_DeInit(&TimHandle);

  /* Connect input signal */
  HSI16_Timer_ConnectInput();

  /* Initialize TIMx peripheral as follows:
       + Period = 0xFFFF
       + Prescaler = 0
       + ClockDivision = 0
       + Counter direction = Up
  */
  TimHandle.Init.Period            = 0xFFFF;
  TimHandle.Init.Prescaler         = HSI16_TIMx_COUNTER_PRESCALER;
  TimHandle.Init.ClockDivision     = 0;
  TimHandle.Init.CounterMode       = TIM_COUNTERMODE_UP;
  if (HAL_TIM_IC_Init(&TimHandle) != HAL_OK)
  {
    /* Initialization Error */
    Error_Handler();
  }

  /* Configure the Input Capture of channel y */
  ic_config.ICPolarity  = TIM_ICPOLARITY_RISING;
  ic_config.ICSelection = TIM_ICSELECTION_DIRECTTI;
  ic_config.ICPrescaler = HSI16_TIMx_IC_DIVIDER;
  ic_config.ICFilter    = 0;
  if (HAL_TIM_IC_ConfigChannel(&TimHandle, &ic_config, TIM_CHANNEL_y) != HAL_OK)
  {
    /* Configuration Error */
    Error_Handler();
  }

  /* Configure the NVIC for TIMx */
  HAL_NVIC_SetPriority(TIMx_IRQn, 0, 1);

  /* Disable the TIMx global Interrupt */
  HAL_NVIC_DisableIRQ(TIMx_IRQn);

}


/**
  * @brief  Adjust calibration value (writing to trimming bits) of selected oscillator.
  * @param  InternOsc: Internal Oscillator source: HSI
  * @param  TrimmingValue: calibration value to be written in trimming bits.
  * @retval None.
  */
void HSI16_RCC_AdjustCalibrationValue(uint8_t InternOsc, uint8_t TrimmingValue)
{
  __HAL_RCC_HSI_CALIBRATIONVALUE_ADJUST(TrimmingValue);
}

/**
  * @brief  Configures LSE to be used as RTC clock source
  * @param  None.
  * @retval None.
  */
void CLK_ConfigForCalibration(void)
{
#ifdef USE_REFERENCE_LSE

  /* Enable the LSE OSC */
  __HAL_RCC_LSE_CONFIG(RCC_LSE_ON);

  /* Wait till LSE is ready */
  while (__HAL_RCC_GET_FLAG(RCC_FLAG_LSERDY) == RESET)
  {}

#endif /* USE_REFERENCE_LSE */
}

/**
  * @brief Configures the GPIO: configure each used I/O in the suitable setting
  * @param None.
  * @retval None.
  */
void GPIO_ConfigForCalibration(void)
{
#ifndef USE_REFERENCE_LSE

  GPIO_InitTypeDef gpio_init;

  /* GPIOB clock enable */
  __HAL_RCC_GPIOB_CLK_ENABLE();

  /* TIMx channel 1 pin (PA2) configuration */
  gpio_init.Pin =  GPIO_PIN_13;
  gpio_init.Mode = GPIO_MODE_AF_PP;
  gpio_init.Pull = GPIO_NOPULL;
  gpio_init.Speed = GPIO_SPEED_HIGH;
  gpio_init.Alternate = GPIO_AF6_TIM21;
  HAL_GPIO_Init(GPIOB, &gpio_init);

#endif /* USE_REFERENCE_LSE */

}

/**
  * @}
  */

/******************* (C) COPYRIGHT 2014 STMicroelectronics *****END OF FILE****/
