/**
  ******************************************************************************
  * @file    Project/STM32L0_Internal_RC_Oscillators_Calibration/Src/main.c
  * @author  MCD Application Team
  * @version V0.1.0
  * @date    17-December-2014
  * @brief   Main program body
  ******************************************************************************
  * @attention
  *
  * <h2><center>&copy; COPYRIGHT 2014 STMicroelectronics</center></h2>
  *
  * Licensed under MCD-ST Liberty SW License Agreement V2, (the "License");
  * You may not use this file except in compliance with the License.
  * You may obtain a copy of the License at:
  *
  *        http://www.st.com/software_license_agreement_liberty_v2
  *
  * Unless required by applicable law or agreed to in writing, software
  * distributed under the License is distributed on an "AS IS" BASIS,
  * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
  * See the License for the specific language governing permissions and
  * limitations under the License.
  *
  ******************************************************************************
  */

/* Includes ------------------------------------------------------------------*/
#include "main.h"
#include "stm32l0538_discovery_epd.h"
#include "stm32l0xx_hal_rtc.h"
#include "lsimeasurement.h"
#include "hsi48.h"
#include "hsi16.h"
#include "msi.h"

/* Private typedef -----------------------------------------------------------*/
/* Private define ------------------------------------------------------------*/
 #define CALIBRATION_MIN_ERROR 
/* Enable this define to use the Fixed error method to calibrate the HSI and
   HSI14 oscillators */
/* #define FIXED_ERROR */
/* Enable this define to use the Measured curve error method to calibrate the HSI and
   HSI14 oscillators */
/* #define ERROR_CURVE */


/* Private macro -------------------------------------------------------------*/
/* Private variables ---------------------------------------------------------*/
static uint32_t TimingDelay;
uint32_t  StartCalibration = 0;
uint16_t  LSIFrequency = LSI_VALUE;
uint32_t  HSIFrequencyBeforeCalib, HSIFrequencyAfterCalib;
uint32_t  MSIFrequencyBeforeCalib, MSIFrequencyAfterCalib;
uint32_t  HSI48FrequencyBeforeCalib, HSI48FrequencyAfterCalib;
uint32_t  __IO CaptureState = 0;
uint32_t  __IO Capture = 0;
uint32_t  IC1ReadValue1 = 0, IC1ReadValue2 = 0;
int32_t  aFrequenceChangeTable[256]; /* 2^8 positions for MSI */
uint32_t  TrimmingCurveMeasured;
TIM_HandleTypeDef       TimHandle; /* Timer handler declaration */

/* Private function prototypes -----------------------------------------------*/
static void EPD_Display(void);

/* Private functions ---------------------------------------------------------*/

/** @addtogroup STM32L0xx_AN4631
  * @{
  */
	
/**
  * @brief  Main program.
  * @param  None
  * @retval None
  */
int main(void)
{

  /* STM32F0xx HAL library initialization:
       - Configure the Flash prefetch
       - Systick timer is configured by default as source of time base, but user 
         can eventually implement his proper time base source (a general purpose 
         timer for example or other time source), keeping in mind that Time base 
         duration should be kept 1ms since PPP_TIMEOUT_VALUEs are defined and 
         handled in milliseconds basis.
       - Low Level Initialization
  */

  HAL_Init();

  /* Initialize the EPD */
  BSP_EPD_Init();

  /* Turn on leds available on STM320518-EVAL *********************************/
  BSP_LED_Init(LED3);
  BSP_LED_Init(LED4);

  BSP_LED_On(LED3);
  BSP_LED_On(LED4);

  /************************** Start the Calibration ***************************/
  /* Enable Calibration */
  StartCalibration = 1;
  HSI16_MeasurementInit();
  HSIFrequencyBeforeCalib = HSI16_FreqMeasure();
  MSI_MeasurementInit();
  MSIFrequencyBeforeCalib = MSI_FreqMeasure();

#ifdef CALIBRATION_MIN_ERROR
  /* Calibrates internal oscillators HSI16 to the minimum computed error */
  HSIFrequencyAfterCalib = HSI16_CalibrateMinError();
  MSIFrequencyAfterCalib = MSI_CalibrateMinError();

#elif defined FIXED_ERROR /* not CALIBRATION_MIN_ERROR */
  /* Calibrate HSI16 oscillator with the maximum allowed error in Hz */
  /* Fix the maximum value of the error frequency at +/- 40000Hz */
  HSI16_CalibrateFixedError(40000, &HSIFrequencyAfterCalib);
  /* Calibrate MSI oscillator with the maximum allowed error in Hz */
  /* Fix the maximum value of the error frequency at +/- 20000Hz */
  MSI_CalibrateFixedError(20000, &MSIFrequencyAfterCalib);

#elif defined  ERROR_CURVE /* not CALIBRATION_MIN_ERROR */
  /* Measure the HSI16 calibration curve */
  HSI16_GetCurve();
  /* Choose the optiomal value on the curve */
  HSI16_CalibrateCurve((uint32_t*)&HSIFrequencyAfterCalib);

  /* Measure the MSI calibration curve */
  MSI_GetCurve();
  /* Choose the optiomal value on the curve */
  MSI_CalibrateCurve((uint32_t*)&MSIFrequencyAfterCalib);

#else           /* not CALIBRATION_MIN_ERROR */
  exit(0);
#endif          /* CALIBRATION_MIN_ERROR */

  /* Measure LSI oscillator frequency after HSI calibration */
  LSIFrequency = LSI_FreqMeasure(HAL_RCC_GetSysClockFreq());

  /* Measure HSI48 before calibration */
  HSI48FrequencyBeforeCalib = HSI48_FreqMeasure();

  //HSI48_SystemClock_Config();
  HSI48FrequencyAfterCalib = HSI48_ManualTrimming();

  /************************ Display results on the EPD ************************/
  EPD_Display();

  /* Infinite loop */
  while (1)
  {
    /* Toggle LD3 */
    BSP_LED_Toggle(LED3);

    /* Insert 50 ms delay */
    HAL_Delay(50);

    /* Toggle LD4 */
    BSP_LED_Toggle(LED4);

    /* Insert 50 ms delay */
    HAL_Delay(50);
  }
}

/**
  * @brief  Display HSI16, HSI48, LSI and MSI frequencies on the EPD.
  * @param  None.
  * @retval None
  */
static void EPD_Display(void)
{
  uint8_t hsidegit1 = 0, hsidegit2 = 0, hsidegit3 = 0;
  uint8_t hsi48degit1 = 0, hsi48degit2 = 0, hsi48degit3 = 0;
  uint8_t msidegit1 = 0, msidegit2 = 0, msidegit3 = 0;
  uint8_t lsidegit1 = 0, lsidegit2 = 0, lsidegit3 = 0;
  uint8_t txbuffer[20];

  lsidegit1 = (LSIFrequency / 1000);
  lsidegit2 = (LSIFrequency % 1000) / 100;
  lsidegit3 = (LSIFrequency % 100) / 10;

  BSP_EPD_Clear(EPD_COLOR_WHITE);
  BSP_EPD_SetFont(&Font12);

  /* Display the LSI oscillator frequency */
  BSP_EPD_DisplayStringAt(0, 15, (uint8_t*)"STM32L0 Osc Calibration", CENTER_MODE);

  /* Display the LSI oscillator frequency */
  sprintf((char*)txbuffer, "LSI Value = %d.%d%d kHz", lsidegit1, lsidegit2, lsidegit3);
  BSP_EPD_DisplayStringAt(0, 12, (uint8_t*)txbuffer, LEFT_MODE);

  /* Display Message on the EPD */
  BSP_EPD_DisplayStringAt(0, 9, (uint8_t*)"     HSI    MSI   HSI48", LEFT_MODE);

  hsidegit1 = (HSIFrequencyBeforeCalib / 1000000);
  hsidegit2 = (HSIFrequencyBeforeCalib % 1000000) / 100000;
  hsidegit3 = (HSIFrequencyBeforeCalib % 100000) / 10000;

  msidegit1 = (MSIFrequencyBeforeCalib / 1000000);
  msidegit2 = (MSIFrequencyBeforeCalib % 1000000) / 100000;
  msidegit3 = (MSIFrequencyBeforeCalib % 100000) / 10000;

  hsi48degit1 = (HSI48FrequencyBeforeCalib / 1000000);
  hsi48degit2 = (HSI48FrequencyBeforeCalib % 1000000) / 100000;
  hsi48degit3 = (HSI48FrequencyBeforeCalib % 100000) / 10000;

  sprintf((char*)txbuffer, " %d.%d%d  %d.%d%d  %d.%d%d", hsidegit1, hsidegit2,
          hsidegit3, msidegit1, msidegit2, msidegit3, hsi48degit1, hsi48degit2, hsi48degit3);
  BSP_EPD_DisplayStringAt(0, 6, (uint8_t*)"Bef:", LEFT_MODE);
  BSP_EPD_DisplayStringAt(24, 6, (uint8_t*)txbuffer, LEFT_MODE);


  /* Display the LSI oscillator frequency */
  BSP_EPD_DisplayStringAt(0, 52, txbuffer, LEFT_MODE);

  hsidegit1 = (HSIFrequencyAfterCalib / 1000000);
  hsidegit2 = (HSIFrequencyAfterCalib % 1000000) / 100000;
  hsidegit3 = (HSIFrequencyAfterCalib % 100000) / 10000;

  msidegit1 = (MSIFrequencyAfterCalib / 1000000);
  msidegit2 = (MSIFrequencyAfterCalib % 1000000) / 100000;
  msidegit3 = (MSIFrequencyAfterCalib % 100000) / 10000;

  hsi48degit1 = (HSI48FrequencyAfterCalib / 1000000);
  hsi48degit2 = (HSI48FrequencyAfterCalib % 1000000) / 100000;
  hsi48degit3 = (HSI48FrequencyAfterCalib % 100000) / 10000;

  sprintf((char*)txbuffer, " %d.%d%d  %d.%d%d  %d.%d%d", hsidegit1, hsidegit2,
          hsidegit3, msidegit1, msidegit2, msidegit3, hsi48degit1, hsi48degit2, hsi48degit3);

  /* Display Message on the EPD */
  BSP_EPD_DisplayStringAt(0, 3, (uint8_t*)"Aft:", LEFT_MODE);
  BSP_EPD_DisplayStringAt(24, 3, (uint8_t*)txbuffer, LEFT_MODE);

  BSP_EPD_DisplayStringAt(0, 0, (uint8_t*)"     MHz    MHz   MHz ", LEFT_MODE);

  BSP_EPD_RefreshDisplay();
}

/**
  * @brief  Conversion complete callback in non blocking mode
  * @param  htim : hadc handle
  * @retval None
  */
void HAL_TIM_IC_CaptureCallback(TIM_HandleTypeDef *htim)
{

  if ((htim->Channel) == HAL_TIM_ACTIVE_CHANNEL_y)
  {
    if (CaptureState == CAPTURE_START)
    {
      /* Get the 1st Input Capture value */
      IC1ReadValue1 = HAL_TIM_ReadCapturedValue(htim, TIM_CHANNEL_y);
      CaptureState = CAPTURE_ONGOING;
    }
    else if (CaptureState == CAPTURE_ONGOING)
    {
      /* Get the 2nd Input Capture value */
      IC1ReadValue2 = HAL_TIM_ReadCapturedValue(htim, TIM_CHANNEL_y);

      /* Capture computation */
      if (IC1ReadValue2 > IC1ReadValue1)
      {
        Capture = (IC1ReadValue2 - IC1ReadValue1);
      }
      else if (IC1ReadValue2 < IC1ReadValue1)
      {
        Capture = ((0xFFFF - IC1ReadValue1) + IC1ReadValue2);
      }
      else
      {
        /* If capture values are equal, we have reached the limit of frequency
        measures */
        Error_Handler();
      }

      CaptureState = CAPTURE_COMPLETED;
    }
  }
}

/**
  * @brief  This function is executed in case of error occurrence.
  * @param  None
  * @retval None
  */
void Error_Handler(void)
{
  /* Turn LED3 on */
  BSP_LED_On(LED3);
  /* Turn LED4 on */
  BSP_LED_On(LED4);
  while (1)
  {}
}

/**
  * @brief  Decrements the TimingDelay variable.
  * @param  None
  * @retval None
  */
void TimingDelay_Decrement(void)
{
  if (TimingDelay != 0x00)
  {
    TimingDelay--;
  }
}

/**
  * @brief  Configures System clock to 16 MHz, clocked by HSI.
  * @note   This function assumes that the HSI is already enabled
  * @param  None.
  * @retval None.
  */
void SetSysClock_HSI16(void)
{
  RCC_ClkInitTypeDef  clk_init;
  RCC_OscInitTypeDef  osc_init;

  /* Enable Power Control clock */
  __HAL_RCC_PWR_CLK_ENABLE();

  /* Enable HSI oscillator */
  osc_init.OscillatorType = RCC_OSCILLATORTYPE_HSI;
  osc_init.HSIState = RCC_HSI_ON;
	osc_init.HSICalibrationValue = RCC_HSICALIBRATION_DEFAULT; /* Reset value */
  osc_init.HSEState = RCC_HSE_OFF;
  osc_init.PLL.PLLState = RCC_PLL_NONE;
  if (HAL_RCC_OscConfig(&osc_init) != HAL_OK)
  {
    /* Initialization Error */
    Error_Handler();
  }

  /* Select HSI as system clock source and configure the HCLK, PCLK1 clocks dividers */
  clk_init.ClockType = (RCC_CLOCKTYPE_SYSCLK | RCC_CLOCKTYPE_HCLK | RCC_CLOCKTYPE_PCLK1);
  clk_init.SYSCLKSource = RCC_SYSCLKSOURCE_HSI;
  clk_init.AHBCLKDivider = RCC_SYSCLK_DIV1;
  clk_init.APB1CLKDivider = RCC_HCLK_DIV1;
  if (HAL_RCC_ClockConfig(&clk_init, FLASH_LATENCY_1) != HAL_OK)
  {
    Error_Handler();
  }
}

/**
  * @brief  Configures System clock to 1.048 MHz
  * @param  None.
  * @retval None.
  */
void SetSysClock_MSI(void)
{
  RCC_ClkInitTypeDef clk_init;
  RCC_OscInitTypeDef osc_init;

  /* Enable Power Control clock */
  __HAL_RCC_PWR_CLK_ENABLE();

  /* Enable MSI oscillator */
  osc_init.OscillatorType = RCC_OSCILLATORTYPE_MSI;
  osc_init.MSIState = RCC_MSI_ON;
  osc_init.MSICalibrationValue = RCC_MSICALIBRATION_DEFAULT;
  osc_init.MSIClockRange = RCC_MSIRANGE_4;
	osc_init.PLL.PLLState = RCC_PLL_NONE;
  if (HAL_RCC_OscConfig(&osc_init) != HAL_OK)
  {
    /* Initialization Error */
    Error_Handler();
  }

  /* Select MSI as system clock source and configure the HCLK, PCLK1 clocks dividers */
  clk_init.ClockType = (RCC_CLOCKTYPE_SYSCLK | RCC_CLOCKTYPE_HCLK | RCC_CLOCKTYPE_PCLK1);
  clk_init.SYSCLKSource = RCC_SYSCLKSOURCE_MSI;
  clk_init.AHBCLKDivider = RCC_SYSCLK_DIV1;
  clk_init.APB1CLKDivider = RCC_HCLK_DIV1;
  if (HAL_RCC_ClockConfig(&clk_init, FLASH_LATENCY_0) != HAL_OK)
  {
    Error_Handler();
  }
}

/**
  * @brief  Configures System clock to 32 MHz. PLL (clocked by HSI16) is used as
  *         System clock source
  * @note   This function assumes that the HSI is already enabled
  * @param  None.
  * @retval None.
  */
void SetSysClock_PLLHSI16_32MHz(void)
{
  RCC_ClkInitTypeDef RCC_ClkInitStruct;
  RCC_OscInitTypeDef RCC_OscInitStruct;

  /* Enable HSI Oscillator and Activate PLL with HSI as source */
  if (__HAL_RCC_GET_SYSCLK_SOURCE() == RCC_CFGR_SWS_HSI)
  {
    RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_NONE;
  }
  else
  {
    RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSI;
    RCC_OscInitStruct.HSIState = RCC_HSI_ON;
  }
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSI;
  RCC_OscInitStruct.PLL.PLLMUL = RCC_PLLMUL_4;
  RCC_OscInitStruct.PLL.PLLDIV = RCC_PLLDIV_2;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }

  /* Select PLL as system clock source and configure the HCLK, PCLK1 clocks dividers */
  RCC_ClkInitStruct.ClockType = (RCC_CLOCKTYPE_SYSCLK | RCC_CLOCKTYPE_HCLK | RCC_CLOCKTYPE_PCLK1);
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV4;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV2;
  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_1) != HAL_OK)
  {
    Error_Handler();
  }
}



#ifdef  USE_FULL_ASSERT

/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t* file, uint32_t line)
{
  /* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */

  /* Infinite loop */
  while (1)
  {}
}
#endif /* USE_FULL_ASSERT */

/**
  * @}
  */

/************************ (C) COPYRIGHT STMicroelectronics *****END OF FILE****/
