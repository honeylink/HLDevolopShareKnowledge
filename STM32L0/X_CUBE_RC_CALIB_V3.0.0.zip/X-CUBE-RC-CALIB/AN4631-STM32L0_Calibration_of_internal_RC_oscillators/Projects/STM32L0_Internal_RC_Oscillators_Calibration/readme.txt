/**
  @page RCC_CRS_Synchonization_IT RCC Clock Recovery Service example
  
  @verbatim
  ******************** (C) COPYRIGHT 2014 STMicroelectronics *******************
  * @file    STM32L0_Internal_RC_Oscillators_Calibration/readme.txt
  * @author  MCD Application Team
  * @version 0.1.0
  * @date    17-December-2014
  * @brief   Description of the AN4631 "STM32L0xxx Internal RC oscillators calibration".
  ******************************************************************************
  *
  * Redistribution and use in source and binary forms, with or without modification,
  * are permitted provided that the following conditions are met:
  *   1. Redistributions of source code must retain the above copyright notice,
  *      this list of conditions and the following disclaimer.
  *   2. Redistributions in binary form must reproduce the above copyright notice,
  *      this list of conditions and the following disclaimer in the documentation
  *      and/or other materials provided with the distribution.
  *   3. Neither the name of STMicroelectronics nor the names of its contributors
  *      may be used to endorse or promote products derived from this software
  *      without specific prior written permission.
  *
  * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
  * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
  * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
  * DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE
  * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
  * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
  * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
  * CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
  * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
  * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
  *
  ******************************************************************************
  @endverbatim

@par Example Description 

 This application note describes a firmware that:
    1- calibrates the internal RC oscillators (HSI16, HSI48 and MSI) using an accurate 
       reference frequency.
    2- measures the internal RC oscillators (LSI)

  The firmware first calibrates the HSI16 oscillator (selected as system clock
  source) with minimum error method using LSE oscillator as reference signal.
  Then MSI is calibrated also with minimum error method but MSI is set through MCO as 
  reference signal and timer clock is set to PLL sourced by HSI16.
  As last HSI48 oscillator is calibrated. For calibration CRS (Clock Recovery System) is used.
  
  Once all the calibrations have finished, the HSI16, MSI, LSI and HSI48 values are 
  displayed.
 
@par Directory contents 

 - "STM32L0_Internal_RC_Oscillators_Calibration\inc": contains the firmware header files 
    - main.h                   Main header file
    - hsi16.h   			   HSI16 calibration configuration file
	- msi.h   			       HSI14 calibration configuration file
	- hsi48.h   			   HSI48 calibration configuration file
    - lsimeasurement.h         LSI measurement configuration file
    - stm32l0xx_hal_conf.h     HAL Configuration file
    - stm32l0xx_it.h           Interrupt handlers header 
	- usbd_conf.h              USB device driver
	- usbd_desc.h              USB device descriptor
	- usbd_dfu_flash.h         Internal flash memory management header file


 - "STM32L0_Internal_RC_Oscillators_Calibration\MDK-ARM": contains pre-configured project for RVMDK toolchain

 - "STM32L0_Internal_RC_Oscillators_Calibration\EWARM": contains pre-configured project for EWARM toolchain

 - "STM32L0_Internal_RC_Oscillators_Calibration\TrueSTUDIO": contains pre-configured project for TrueSTUDIO toolchain

  - "STM32L0_Internal_RC_Oscillators_Calibration\Src": contains the firmware source files
    - main.c                   Main program
    - hsi16.c 				   HSI16 calibration routines
    - msi.c   			       MSI calibration routines
    - hsi48.c   			   HSI48 calibration routines
    - lsimeasurement.c         LSI measurement routine 
    - stm32l0xx_it.c           Interrupt routines source
	- system_stm32l0xx.c	   STM32L0xx system clock
	

@par Hardware and Software environment

  - This example runs on STM32L0xx devices.
  
  - This example has been tested with STMicroelectronics STM32L0538-DISCO evaluation board and can be easily tailored to any 
    other supported device and development board. ONly USB line (STM32L0x2 and STM32L0x2) can use as source of reference signal USB Start Of Frame.

  - STM32L0538-DISCO Set-up
     - Leds: LD3 and LD4
     - By default, the external reference frequency is used, connect the source to PB13.
       (The source voltage levels have to correspond to levels allowed for this pin).
     - By default, for HSI48 the USB Start Of Frame is used as source for CRS so connect another USB cable between PC and CN4 of STM32L0538-DISCO. For this demonstration purpose there is no
	   USB functionality implemented, so that it's not recognised by PC as valid USB device. 
	   In case of using other reference frequency for HSI48 measurement, connect the source to PA8.
	 
@par How to use it ? 

In order to make the program work, you must do the following :
 - Open your preferred toolchain 
 - Rebuild all files and load your image into target memory
 - If necessary connect the external reference source to appropriate pin 
 - Run the example

 * <h3><center>&copy; COPYRIGHT STMicroelectronics</center></h3>
 */
