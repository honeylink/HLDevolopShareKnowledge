/**
  ******************************************************************************
  * @file    Project/STM32L0_Internal_RC_Oscillators_Calibration/Inc/main.h 
  * @author  MCD Application Team
  * @version V0.1.0
  * @date    17-December-2014
  * @brief   Header for main.c module
  ******************************************************************************
  * @attention
  *
  * <h2><center>&copy; COPYRIGHT 2014 STMicroelectronics</center></h2>
  *
  * Licensed under MCD-ST Liberty SW License Agreement V2, (the "License");
  * You may not use this file except in compliance with the License.
  * You may obtain a copy of the License at:
  *
  *        http://www.st.com/software_license_agreement_liberty_v2
  *
  * Unless required by applicable law or agreed to in writing, software
  * distributed under the License is distributed on an "AS IS" BASIS,
  * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
  * See the License for the specific language governing permissions and
  * limitations under the License.
  *
  ******************************************************************************
  */
  
/* Define to prevent recursive inclusion -------------------------------------*/
#ifndef __MAIN_H
#define __MAIN_H

/* Includes ------------------------------------------------------------------*/
#ifdef USE_STM32L0538_DISCO
#include "stm32l0538_discovery.h"
#elif USE_STM32L0XX_NUCLEO
#include "stm32l0xx_nucleo.h"
#endif
#include "stm32l0xx_hal.h"
#include "stm32l0xx.h"
#include <stdio.h>

/* Exported types ------------------------------------------------------------*/
/* Exported constants --------------------------------------------------------*/
#define CAPTURE_START        			((uint32_t) 0x00000001)
#define CAPTURE_ONGOING      			((uint32_t) 0x00000002)
#define CAPTURE_COMPLETED    			((uint32_t) 0x00000003)


#define LSI_VALUE									((uint32_t)37000)

#define __TIMx_CLK_ENABLE()  			__HAL_RCC_TIM21_CLK_ENABLE()
#define	TIMx 											TIM21
#define	TIM_CHANNEL_y							TIM_CHANNEL_1
#define	HAL_TIM_ACTIVE_CHANNEL_y 	HAL_TIM_ACTIVE_CHANNEL_1
#define	TIM_TIMx_GPIO							TIM21_TI1_GPIO
#define	TIM_TIMx_LSE							TIM21_TI1_LSE
#define	TIM_TIMx_MCO							TIM21_TI1_MCO
#define	TIMx_IRQn									TIM21_IRQn

#define INITIAL_ERROR							((uint32_t)99999000)

/* Exported macro ------------------------------------------------------------*/
#define __HAL_GET_TIM_PRESCALER(__HANDLE__)       ((__HANDLE__)->Instance->PSC)
#define ABS_RETURN(x)         										((x < 0) ? (-x) : (x))

/* Exported variables --------------------------------------------------------*/
extern TIM_HandleTypeDef  TimHandle; /* Timer handler declaration */
extern uint32_t __IO 			CaptureState;
extern uint32_t __IO 			Capture;
extern uint32_t 					StartCalibration;
extern int32_t 						aFrequenceChangeTable[];
extern uint32_t 					TrimmingCurveMeasured;

/* Exported functions ------------------------------------------------------- */
void TimingDelay_Decrement(void);
void Error_Handler(void);
void SetSysClock_HSI16(void);
void SetSysClock_MSI(void);
void SetSysClock_PLLHSI16_32MHz(void);
void CLK_ConfigForCalibration(void);
void GPIO_ConfigForCalibration(void);

#endif /* __MAIN_H */

/************************ (C) COPYRIGHT STMicroelectronics *****END OF FILE****/
